import SwiftUI
import Foundation

struct ContentView: View {

    // MARK: - Проект

    @State private var projectName = "Тестовый проект"

    // MARK: - Условия среды

    @State private var waterDensity = "1025"
    @State private var depth = "50"
    @State private var currentSpeed = "0.5"
    @State private var waveHeight = "1.0"
    @State private var wavePeriod = "6.0"
    @State private var selectedSeabedPresetId = "unknown"

    // MARK: - Буй

    @State private var selectedBuoyPresetId = "cylinder_08x10_80"
    @State private var userBuoyPresets: [UserBuoyDraft] = []
    @State private var customBuoyName = "Мой буй"
    @State private var buoySourceKind: DataSourceKind = .userInput
    @State private var buoySourceManufacturer = ""
    @State private var buoySourceModel = ""
    @State private var buoySourceDocument = ""
    @State private var buoySourcePage = ""
    @State private var buoySourceComment = "Значение введено пользователем вручную."
    @State private var buoyLibraryMessage = ""
    @State private var selectedBuoyShape: BuoyShape = .cylinder

    @State private var buoyDiameter = "0.8"
    @State private var buoyHeight = "1.0"
    @State private var buoyCustomVolume = "0.50"

    @State private var buoyWeight = "80"
    @State private var buoyDragCoefficient = "0.8"

    // MARK: - Швартовная линия

    @State private var systemSafetyFactor = "5"

    @State private var assemblyItems: [MooringAssemblyItemDraft] = MooringAssemblyItemDraft.defaultItems()
    @State private var selectedNewAssemblyKind: MooringAssemblyItemKind = .line
    @State private var assemblyMessage = ""

    @State private var userRopePresets: [UserRopeDraft] = []
    @State private var selectedUserRopeEditorId = ""
    @State private var customRopeName = "Мой участок линии"
    @State private var customRopeMaterial = "Polyester / Полиэстер"
    @State private var customRopeDiameter = "20"
    @State private var customRopeBreakingLoad = "70"
    @State private var customRopeWeightWater = "0.15"
    @State private var customRopeDragCoefficient = "1.2"
    @State private var ropeSourceKind: DataSourceKind = .userInput
    @State private var ropeSourceManufacturer = ""
    @State private var ropeSourceModel = ""
    @State private var ropeSourceDocument = ""
    @State private var ropeSourcePage = ""
    @State private var ropeSourceComment = "Значение введено пользователем вручную."
    @State private var ropeLibraryMessage = ""

    @State private var userConnectorPresets: [UserConnectorDraft] = []
    @State private var selectedUserConnectorEditorId = ""
    @State private var customConnectorName = "Мой соединитель"
    @State private var customConnectorType = "Скоба"
    @State private var customConnectorWeightAir = "1.0"
    @State private var customConnectorVolume = "0.0001"
    @State private var customConnectorBreakingLoad = "55"
    @State private var customConnectorProjectedArea = "0.005"
    @State private var customConnectorDragCoefficient = "1.2"
    @State private var connectorSourceKind: DataSourceKind = .userInput
    @State private var connectorSourceManufacturer = ""
    @State private var connectorSourceModel = ""
    @State private var connectorSourceDocument = ""
    @State private var connectorSourcePage = ""
    @State private var connectorSourceComment = "Значение введено пользователем вручную."
    @State private var connectorLibraryMessage = ""

    @State private var selectedSegment1PresetId = "polyester_20"
    @State private var segment1Length = "45"

    @State private var useSegment2 = true
    @State private var selectedSegment2PresetId = "chain_10"
    @State private var segment2Length = "10"

    @State private var useSegment3 = false
    @State private var selectedSegment3PresetId = "steel_wire_8"
    @State private var segment3Length = "0"

    // MARK: - Соединители

    @State private var useConnector1 = true
    @State private var selectedConnector1PresetId = "shackle_55"
    @State private var connector1Count = "2"

    @State private var useConnector2 = true
    @State private var selectedConnector2PresetId = "swivel_60"
    @State private var connector2Count = "1"

    @State private var useConnector3 = false
    @State private var selectedConnector3PresetId = "acoustic_release_35"
    @State private var connector3Count = "0"

    // MARK: - Прибор

    @State private var payloadName = "ADCP"
    @State private var payloadWeightAir = "40"
    @State private var payloadVolume = "0"
    @State private var payloadProjectedArea = "0.05"
    @State private var payloadDragCoefficient = "1.0"

    // MARK: - Якорь

    @State private var selectedAnchorPresetId = "concrete_300"
    @State private var userAnchorPresets: [UserAnchorDraft] = []
    @State private var anchorName = "Concrete block 300 kg"
    @State private var anchorType = "Бетонный груз"
    @State private var anchorMaterial = "Concrete / Бетон"
    @State private var anchorSourceKind: DataSourceKind = .userInput
    @State private var anchorSourceManufacturer = ""
    @State private var anchorSourceModel = ""
    @State private var anchorSourceDocument = ""
    @State private var anchorSourcePage = ""
    @State private var anchorSourceComment = "Значение введено пользователем вручную."
    @State private var anchorLibraryMessage = ""

    @State private var anchorWeightAir = "300"
    @State private var anchorVolume = "0.125"
    @State private var anchorBaseHoldingCoefficient = "1.0"

    // MARK: - Результат

    @State private var resultText = "Введите данные на вкладках «Проект» и «Элементы», затем нажмите «Рассчитать»."
    @State private var reportText = "Отчёт будет сформирован после расчёта."
    @State private var reportPDFData = Data()
    @State private var lastResult: CalculationResult?
    @State private var isReportPreviewPresented = false

    // MARK: - Сохранённые проекты

    @State private var savedProjects: [SavedBuoyCalcProject] = []
    @State private var selectedSavedProjectId = ""
    @State private var storageMessage = ""

    var body: some View {
        TabView {
            projectTab
                .tabItem {
                    Label("Проект", systemImage: "folder")
                }

            elementsTab
                .tabItem {
                    Label("Элементы", systemImage: "link")
                }

            LibraryView()
                .tabItem {
                    Label("Библиотека", systemImage: "books.vertical")
                }

            resultTab
                .tabItem {
                    Label("Результат", systemImage: "checkmark.seal")
                }
        }
        .onAppear {
            refreshUserBuoyPresets()
            refreshUserRopePresets()
            refreshUserConnectorPresets()
            refreshUserAnchorPresets()
            applySelectedBuoyPreset()
            applySelectedAnchorPreset()
            refreshSavedProjects()
        }
        .sheet(isPresented: $isReportPreviewPresented) {
            ReportPreviewView(
                projectName: projectName,
                reportText: reportText,
                pdfData: reportPDFData
            )
        }
    }

    // MARK: - Вкладка «Проект»

    var projectTab: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    Text("BuoyCalc")
                        .font(.largeTitle)
                        .bold()

                    sectionTitle("Проект")

                    textInputField("Название проекта", text: $projectName)

                    VStack(alignment: .leading, spacing: 10) {
                        Button(action: saveCurrentProject) {
                            Text(selectedSavedProjectId.isEmpty ? "Сохранить как новый проект" : "Обновить выбранный проект")
                                .font(.headline)
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(Color.green.opacity(0.85))
                                .foregroundColor(.white)
                                .cornerRadius(12)
                        }

                        if savedProjects.isEmpty {
                            Text("Сохранённых проектов пока нет.")
                                .font(.caption)
                                .foregroundColor(.secondary)
                        } else {
                            Picker("Сохранённые проекты", selection: $selectedSavedProjectId) {
                                Text("Не выбран").tag("")

                                ForEach(savedProjects) { project in
                                    Text(project.displayName).tag(project.id)
                                }
                            }
                            .pickerStyle(.menu)

                            Button(action: loadSelectedProject) {
                                Text("Загрузить выбранный проект")
                                    .font(.headline)
                                    .frame(maxWidth: .infinity)
                                    .padding()
                                    .background(Color.blue.opacity(0.85))
                                    .foregroundColor(.white)
                                    .cornerRadius(12)
                            }

                            Button(action: deleteSelectedProject) {
                                Text("Удалить выбранный проект")
                                    .font(.headline)
                                    .frame(maxWidth: .infinity)
                                    .padding()
                                    .background(Color.red.opacity(0.75))
                                    .foregroundColor(.white)
                                    .cornerRadius(12)
                            }
                        }

                        Button(action: startNewProject) {
                            Text("Новый проект")
                                .font(.headline)
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(Color.gray.opacity(0.35))
                                .foregroundColor(.primary)
                                .cornerRadius(12)
                        }

                        if !storageMessage.isEmpty {
                            Text(storageMessage)
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                    }

                    sectionTitle("Условия среды")

                    numberInputField("Плотность воды, кг/м³", text: $waterDensity)
                    numberInputField("Глубина, м", text: $depth)
                    numberInputField("Скорость течения, м/с", text: $currentSpeed)
                    numberInputField("Высота волны, м", text: $waveHeight)
                    numberInputField("Период волны, с", text: $wavePeriod)

                    Picker("Тип грунта", selection: $selectedSeabedPresetId) {
                        ForEach(SeabedCatalog.presets) { preset in
                            Text(preset.displayName).tag(preset.id)
                        }
                    }
                    .pickerStyle(.menu)

                    Text(SeabedCatalog.presetById(selectedSeabedPresetId).note)
                        .font(.caption)
                        .foregroundColor(.secondary)

                    infoBox(
                        title: "Что задаётся здесь",
                        text: "На этой вкладке задаются внешние условия: глубина, течение, волна и тип грунта. Эти данные влияют на снос, натяжение и удержание якоря."
                    )
                }
                .padding()
            }
            .navigationTitle("Проект")
        }
    }

    // MARK: - Вкладка «Элементы»

    var elementsTab: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {

                    sectionTitle("Буй")

                    Picker("Пресет буя", selection: $selectedBuoyPresetId) {
                        Text("Пользовательские значения").tag("manual")

                        ForEach(BuoyCatalog.presets) { preset in
                            Text(preset.displayName).tag(preset.id)
                        }

                        ForEach(userBuoyPresets) { preset in
                            Text("★ \(preset.displayName)").tag("user:\(preset.id)")
                        }
                    }
                    .pickerStyle(.menu)
                    .onChange(of: selectedBuoyPresetId) { _ in
                        applySelectedBuoyPreset()
                    }

                    if selectedBuoyPresetId == "manual" {
                        Text("Используются введённые вручную параметры буя.")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    } else if let userBuoy = selectedUserBuoy() {
                        Text(userBuoy.note)
                            .font(.caption)
                            .foregroundColor(.secondary)
                    } else {
                        Text(BuoyCatalog.presetById(selectedBuoyPresetId).note)
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }

                    Picker("Форма буя", selection: $selectedBuoyShape) {
                        ForEach(BuoyShape.allCases) { shape in
                            Text(shape.rawValue).tag(shape)
                        }
                    }
                    .pickerStyle(.segmented)

                    if selectedBuoyShape == .custom {
                        numberInputField("Паспортный объём буя, м³", text: $buoyCustomVolume)
                        numberInputField("Диаметр / ширина для сопротивления, м", text: $buoyDiameter)
                        numberInputField("Высота для сопротивления, м", text: $buoyHeight)
                    } else if selectedBuoyShape == .sphere {
                        numberInputField("Диаметр буя, м", text: $buoyDiameter)
                    } else {
                        numberInputField("Диаметр буя, м", text: $buoyDiameter)
                        numberInputField("Высота буя, м", text: $buoyHeight)
                    }

                    numberInputField("Масса буя, кг", text: $buoyWeight)
                    numberInputField("Коэффициент сопротивления буя", text: $buoyDragCoefficient)

                    VStack(alignment: .leading, spacing: 10) {
                        Text("Пользовательский буй")
                            .font(.headline)

                        textInputField("Название буя для библиотеки", text: $customBuoyName)

                        sourceEditorView(
                            kind: $buoySourceKind,
                            manufacturer: $buoySourceManufacturer,
                            model: $buoySourceModel,
                            document: $buoySourceDocument,
                            page: $buoySourcePage,
                            comment: $buoySourceComment
                        )

                        Button(action: saveCurrentBuoyToLibrary) {
                            Text(selectedUserBuoyId() == nil ? "Сохранить текущий буй в библиотеку" : "Обновить выбранный пользовательский буй")
                                .font(.headline)
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(Color.purple.opacity(0.82))
                                .foregroundColor(.white)
                                .cornerRadius(12)
                        }

                        if selectedUserBuoyId() != nil {
                            Button(action: deleteSelectedUserBuoy) {
                                Text("Удалить выбранный пользовательский буй")
                                    .font(.headline)
                                    .frame(maxWidth: .infinity)
                                    .padding()
                                    .background(Color.red.opacity(0.75))
                                    .foregroundColor(.white)
                                    .cornerRadius(12)
                            }
                        }

                        if !buoyLibraryMessage.isEmpty {
                            Text(buoyLibraryMessage)
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                    }
                    .padding()
                    .background(Color.gray.opacity(0.08))
                    .cornerRadius(12)

                    sectionTitle("Последовательность постановки")

                    infoBox(
                        title: "Новая логика",
                        text: "Система задаётся сверху вниз: буй → элементы постановки → якорь. Можно добавлять сколько угодно соединителей, участков линии и приборов."
                    )

                    numberInputField("Коэффициент запаса системы", text: $systemSafetyFactor)

                    mooringAssemblyView()

                    AssemblySequenceView(
                        buoyTitle: selectedBuoyPreset()?.displayName ?? customBuoyName,
                        items: assemblyItems,
                        anchorTitle: anchorName
                    )

                    userConnectorEditorView()

                    userRopeEditorView()

                    sectionTitle("Якорь")

                    Picker("Тип якоря", selection: $selectedAnchorPresetId) {
                        Text("Пользовательские значения").tag("manual")

                        ForEach(AnchorCatalog.presets) { preset in
                            Text(preset.displayName).tag(preset.id)
                        }

                        ForEach(userAnchorPresets) { preset in
                            Text("★ \(preset.displayName)").tag("user:\(preset.id)")
                        }
                    }
                    .pickerStyle(.menu)
                    .onChange(of: selectedAnchorPresetId) { _ in
                        applySelectedAnchorPreset()
                    }

                    if selectedAnchorPresetId == "manual" {
                        Text("Используются введённые вручную параметры якоря.")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    } else if let userAnchor = selectedUserAnchor() {
                        Text(userAnchor.note)
                            .font(.caption)
                            .foregroundColor(.secondary)
                    } else {
                        Text(AnchorCatalog.presetById(selectedAnchorPresetId).note)
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }

                    textInputField("Название якоря", text: $anchorName)
                    textInputField("Тип якоря", text: $anchorType)
                    textInputField("Материал якоря", text: $anchorMaterial)

                    numberInputField("Масса якоря в воздухе, кг", text: $anchorWeightAir)
                    numberInputField("Объём якоря, м³", text: $anchorVolume)
                    numberInputField("Базовый коэффициент удержания", text: $anchorBaseHoldingCoefficient)

                    VStack(alignment: .leading, spacing: 10) {
                        Text("Пользовательский якорь")
                            .font(.headline)

                        sourceEditorView(
                            kind: $anchorSourceKind,
                            manufacturer: $anchorSourceManufacturer,
                            model: $anchorSourceModel,
                            document: $anchorSourceDocument,
                            page: $anchorSourcePage,
                            comment: $anchorSourceComment
                        )

                        Button(action: saveCurrentAnchorToLibrary) {
                            Text(selectedUserAnchorId() == nil ? "Сохранить текущий якорь в библиотеку" : "Обновить выбранный пользовательский якорь")
                                .font(.headline)
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(Color.purple.opacity(0.82))
                                .foregroundColor(.white)
                                .cornerRadius(12)
                        }

                        if selectedUserAnchorId() != nil {
                            Button(action: deleteSelectedUserAnchor) {
                                Text("Удалить выбранный пользовательский якорь")
                                    .font(.headline)
                                    .frame(maxWidth: .infinity)
                                    .padding()
                                    .background(Color.red.opacity(0.75))
                                    .foregroundColor(.white)
                                    .cornerRadius(12)
                            }
                        }

                        if !anchorLibraryMessage.isEmpty {
                            Text(anchorLibraryMessage)
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                    }
                    .padding()
                    .background(Color.gray.opacity(0.08))
                    .cornerRadius(12)
                }
                .padding()
            }
            .navigationTitle("Элементы")
        }
    }

    // MARK: - Вкладка «Результат»

    var resultTab: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {

                    Text("Результат расчёта")
                        .font(.largeTitle)
                        .bold()

                    Button(action: calculate) {
                        Text("Рассчитать")
                            .font(.headline)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.blue)
                            .foregroundColor(.white)
                            .cornerRadius(12)
                    }

                    if let result = lastResult {
                        VerdictCardView(result: result)

                        SystemChecksView(
                            result: result,
                            depthM: number(depth),
                            lineLengthM: result.mooringLineLengthM
                        )

                        AssemblySequenceView(
                            buoyTitle: selectedBuoyPreset()?.displayName ?? customBuoyName,
                            items: assemblyItems,
                            anchorTitle: anchorName
                        )

                        VStack(alignment: .leading, spacing: 10) {
                            Text("Отчёт")
                                .font(.headline)

                            Button(action: {
                                isReportPreviewPresented = true
                            }) {
                                Text("Открыть предпросмотр отчёта")
                                    .font(.headline)
                                    .frame(maxWidth: .infinity)
                                    .padding()
                                    .background(Color.orange.opacity(0.85))
                                    .foregroundColor(.white)
                                    .cornerRadius(12)
                            }

                            ShareLink(
                                item: reportText,
                                subject: Text("Отчёт BuoyCalc — \(projectName)"),
                                message: Text("Предварительный инженерный отчёт BuoyCalc")
                            ) {
                                Text("Поделиться отчётом")
                                    .font(.headline)
                                    .frame(maxWidth: .infinity)
                                    .padding()
                                    .background(Color.indigo.opacity(0.85))
                                    .foregroundColor(.white)
                                    .cornerRadius(12)
                            }

                            Text("Отчёт можно сначала открыть, проверить, затем отправить или сохранить.")
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }                        .padding()
                        .background(Color.gray.opacity(0.08))
                        .cornerRadius(12)

                        MooringSideView(
                            depthM: number(depth),
                            lineLengthM: result.mooringLineLengthM,
                            estimatedOffsetM: result.estimatedCurrentOffsetM,
                            maxOffsetM: result.maxGeometricOffsetM,
                            currentSpeedMS: number(currentSpeed)
                        )
                    } else {
                        infoBox(
                            title: "Расчёт ещё не выполнен",
                            text: "Проверьте данные на вкладках «Проект» и «Элементы», затем нажмите кнопку «Рассчитать»."
                        )
                    }

                    Text(resultText)
                        .font(.body)
                        .padding()
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(Color.gray.opacity(0.12))
                        .cornerRadius(12)
                }
                .padding()
            }
            .navigationTitle("Результат")
        }
    }

    // MARK: - Элементы интерфейса

    func sectionTitle(_ title: String) -> some View {
        Text(title)
            .font(.title2)
            .bold()
            .padding(.top, 8)
    }

    func textInputField(_ title: String, text: Binding<String>) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(title)
                .font(.caption)
                .foregroundColor(.secondary)

            TextField(title, text: text)
                .textFieldStyle(.roundedBorder)
        }
    }

    func numberInputField(_ title: String, text: Binding<String>) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(title)
                .font(.caption)
                .foregroundColor(.secondary)

            TextField(title, text: text)
                .keyboardType(.decimalPad)
                .textFieldStyle(.roundedBorder)
        }
    }

    func infoBox(title: String, text: String) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(title)
                .font(.headline)

            Text(text)
                .font(.caption)
                .foregroundColor(.secondary)
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.gray.opacity(0.10))
        .cornerRadius(12)
    }


    func mooringAssemblyView() -> some View {
        VStack(alignment: .leading, spacing: 12) {
            VStack(alignment: .leading, spacing: 6) {
                Text("Буй")
                    .font(.headline)

                Text("Верхняя точка постановки. Параметры задаются в разделе «Буй».")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            .padding()
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Color.blue.opacity(0.08))
            .cornerRadius(12)

            if assemblyItems.isEmpty {
                Text("Элементы между буем и якорем пока не заданы.")
                    .font(.caption)
                    .foregroundColor(.secondary)
            } else {
                ForEach(assemblyItems.indices, id: \.self) { index in
                    assemblyItemEditor(index: index)
                }
            }

            VStack(alignment: .leading, spacing: 8) {
                Picker("Что добавить", selection: $selectedNewAssemblyKind) {
                    ForEach(MooringAssemblyItemKind.allCases) { kind in
                        Text(kind.rawValue).tag(kind)
                    }
                }
                .pickerStyle(.segmented)

                Button(action: addAssemblyItem) {
                    Text("Добавить элемент в последовательность")
                        .font(.headline)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.green.opacity(0.85))
                        .foregroundColor(.white)
                        .cornerRadius(12)
                }
            }

            VStack(alignment: .leading, spacing: 6) {
                Text("Якорь")
                    .font(.headline)

                Text("Нижняя точка постановки. Параметры задаются в разделе «Якорь».")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            .padding()
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Color.brown.opacity(0.10))
            .cornerRadius(12)

            if !assemblyMessage.isEmpty {
                Text(assemblyMessage)
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
        }
        .padding()
        .background(Color.gray.opacity(0.08))
        .cornerRadius(16)
    }

    func assemblyItemEditor(index: Int) -> some View {
        let kind = MooringAssemblyItemKind(rawValue: assemblyItems[index].kindRawValue) ?? .line

        return VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text("\(index + 1). \(kind.shortTitle)")
                    .font(.headline)

                Spacer()

                Button("↑") {
                    moveAssemblyItemUp(index)
                }
                .disabled(index == 0)

                Button("↓") {
                    moveAssemblyItemDown(index)
                }
                .disabled(index == assemblyItems.count - 1)

                Button("Удалить") {
                    deleteAssemblyItem(index)
                }
                .foregroundColor(.red)
            }

            Toggle("Использовать элемент", isOn: $assemblyItems[index].isEnabled)

            Picker("Тип элемента", selection: $assemblyItems[index].kindRawValue) {
                ForEach(MooringAssemblyItemKind.allCases) { itemKind in
                    Text(itemKind.rawValue).tag(itemKind.rawValue)
                }
            }
            .pickerStyle(.menu)
            .onChange(of: assemblyItems[index].kindRawValue) { _ in
                normalizeAssemblyItem(index)
            }

            textInputField("Название элемента", text: $assemblyItems[index].title)

            if kind == .line {
                Picker("Тип линии", selection: $assemblyItems[index].presetId) {
                    ForEach(RopeCatalog.presets) { preset in
                        Text(preset.displayName).tag(preset.id)
                    }

                    ForEach(userRopePresets) { preset in
                        Text("★ \(preset.displayName)").tag("user:\(preset.id)")
                    }
                }
                .pickerStyle(.menu)

                Text(ropePresetNote(assemblyItems[index].presetId))
                    .font(.caption)
                    .foregroundColor(.secondary)

                numberInputField("Длина участка, м", text: $assemblyItems[index].lengthText)

            } else if kind == .connector {
                Picker("Тип соединителя", selection: $assemblyItems[index].presetId) {
                    ForEach(ConnectorCatalog.presets) { preset in
                        Text(preset.displayName).tag(preset.id)
                    }

                    ForEach(userConnectorPresets) { preset in
                        Text("★ \(preset.displayName)").tag("user:\(preset.id)")
                    }
                }
                .pickerStyle(.menu)

                Text(connectorPresetNote(assemblyItems[index].presetId))
                    .font(.caption)
                    .foregroundColor(.secondary)

                numberInputField("Количество, шт.", text: $assemblyItems[index].countText)

            } else {
                numberInputField("Масса прибора в воздухе, кг", text: $assemblyItems[index].weightAirText)
                numberInputField("Объём прибора, м³", text: $assemblyItems[index].volumeText)
                numberInputField("Площадь сопротивления, м²", text: $assemblyItems[index].projectedAreaText)
                numberInputField("Коэффициент сопротивления Cd", text: $assemblyItems[index].dragCoefficientText)
            }
        }
        .padding()
        .background(kindBackgroundColor(kind))
        .cornerRadius(12)
    }

    func kindBackgroundColor(_ kind: MooringAssemblyItemKind) -> Color {
        switch kind {
        case .connector:
            return Color.orange.opacity(0.08)
        case .line:
            return Color.cyan.opacity(0.08)
        case .payload:
            return Color.purple.opacity(0.08)
        }
    }


    func segmentInputView(
        title: String,
        presetId: Binding<String>,
        length: Binding<String>,
        isOptional: Bool,
        isEnabled: Binding<Bool>
    ) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            if isOptional {
                Toggle(title, isOn: isEnabled)
                    .font(.headline)
            } else {
                Text(title)
                    .font(.headline)
            }

            if isEnabled.wrappedValue {
                Picker("Тип участка", selection: presetId) {
                    ForEach(RopeCatalog.presets) { preset in
                        Text(preset.displayName).tag(preset.id)
                    }

                    ForEach(userRopePresets) { preset in
                        Text("★ \(preset.displayName)").tag("user:\(preset.id)")
                    }
                }
                .pickerStyle(.menu)

                Text(ropePresetNote(presetId.wrappedValue))
                    .font(.caption)
                    .foregroundColor(.secondary)

                numberInputField("Длина участка, м", text: length)
            }
        }
        .padding()
        .background(Color.gray.opacity(0.08))
        .cornerRadius(12)
    }






    func sourceEditorView(
        title: String = "Источник данных",
        kind: Binding<DataSourceKind>,
        manufacturer: Binding<String>,
        model: Binding<String>,
        document: Binding<String>,
        page: Binding<String>,
        comment: Binding<String>
    ) -> some View {
        DisclosureGroup(title) {
            VStack(alignment: .leading, spacing: 10) {
                Picker("Тип источника", selection: kind) {
                    ForEach(DataSourceKind.allCases) { sourceKind in
                        Text(sourceKind.rawValue).tag(sourceKind)
                    }
                }
                .pickerStyle(.menu)

                textInputField("Производитель", text: manufacturer)
                textInputField("Модель", text: model)
                textInputField("Документ / паспорт / источник", text: document)
                textInputField("Страница", text: page)
                textInputField("Комментарий", text: comment)

                Text("Источник нужен для прозрачности: откуда взяты масса, объём, MBL, Cd и другие параметры.")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            .padding(.top, 8)
        }
        .padding()
        .background(Color.gray.opacity(0.08))
        .cornerRadius(12)
    }

    func makeDataSource(
        kind: DataSourceKind,
        manufacturer: String,
        model: String,
        document: String,
        page: String,
        comment: String
    ) -> ElementDataSource {
        ElementDataSource(
            kindRawValue: kind.rawValue,
            manufacturer: manufacturer,
            model: model,
            document: document,
            page: page,
            comment: comment
        )
    }

    func userConnectorEditorView() -> some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Пользовательский соединитель")
                .font(.headline)

            Picker("Соединитель для редактирования", selection: $selectedUserConnectorEditorId) {
                Text("Новый пользовательский соединитель").tag("")

                ForEach(userConnectorPresets) { preset in
                    Text(preset.displayName).tag(preset.id)
                }
            }
            .pickerStyle(.menu)
            .onChange(of: selectedUserConnectorEditorId) { _ in
                applySelectedUserConnectorToEditor()
            }

            textInputField("Название соединителя", text: $customConnectorName)
            textInputField("Тип", text: $customConnectorType)
            numberInputField("Масса в воздухе, кг", text: $customConnectorWeightAir)
            numberInputField("Объём, м³", text: $customConnectorVolume)
            numberInputField("Разрывная нагрузка MBL, кН", text: $customConnectorBreakingLoad)
            numberInputField("Площадь сопротивления, м²", text: $customConnectorProjectedArea)
            numberInputField("Коэффициент сопротивления Cd", text: $customConnectorDragCoefficient)

            sourceEditorView(
                kind: $connectorSourceKind,
                manufacturer: $connectorSourceManufacturer,
                model: $connectorSourceModel,
                document: $connectorSourceDocument,
                page: $connectorSourcePage,
                comment: $connectorSourceComment
            )

            Button(action: saveCurrentConnectorToLibrary) {
                Text(selectedUserConnectorEditorId.isEmpty ? "Сохранить соединитель в библиотеку" : "Обновить выбранный соединитель")
                    .font(.headline)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.purple.opacity(0.82))
                    .foregroundColor(.white)
                    .cornerRadius(12)
            }

            if !selectedUserConnectorEditorId.isEmpty {
                Button(action: deleteSelectedUserConnector) {
                    Text("Удалить выбранный соединитель")
                        .font(.headline)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.red.opacity(0.75))
                        .foregroundColor(.white)
                        .cornerRadius(12)
                }
            }

            if !connectorLibraryMessage.isEmpty {
                Text(connectorLibraryMessage)
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
        }
        .padding()
        .background(Color.gray.opacity(0.08))
        .cornerRadius(12)
    }


    func userRopeEditorView() -> some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Пользовательский участок линии")
                .font(.headline)

            Picker("Участок для редактирования", selection: $selectedUserRopeEditorId) {
                Text("Новый пользовательский участок").tag("")

                ForEach(userRopePresets) { preset in
                    Text(preset.displayName).tag(preset.id)
                }
            }
            .pickerStyle(.menu)
            .onChange(of: selectedUserRopeEditorId) { _ in
                applySelectedUserRopeToEditor()
            }

            textInputField("Название участка", text: $customRopeName)
            textInputField("Материал", text: $customRopeMaterial)
            numberInputField("Диаметр, мм", text: $customRopeDiameter)
            numberInputField("Разрывная нагрузка, кН", text: $customRopeBreakingLoad)
            numberInputField("Вес в воде, кг/м", text: $customRopeWeightWater)
            numberInputField("Коэффициент сопротивления Cd", text: $customRopeDragCoefficient)

            sourceEditorView(
                kind: $ropeSourceKind,
                manufacturer: $ropeSourceManufacturer,
                model: $ropeSourceModel,
                document: $ropeSourceDocument,
                page: $ropeSourcePage,
                comment: $ropeSourceComment
            )

            Button(action: saveCurrentRopeToLibrary) {
                Text(selectedUserRopeEditorId.isEmpty ? "Сохранить участок линии в библиотеку" : "Обновить выбранный участок линии")
                    .font(.headline)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.purple.opacity(0.82))
                    .foregroundColor(.white)
                    .cornerRadius(12)
            }

            if !selectedUserRopeEditorId.isEmpty {
                Button(action: deleteSelectedUserRope) {
                    Text("Удалить выбранный участок линии")
                        .font(.headline)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.red.opacity(0.75))
                        .foregroundColor(.white)
                        .cornerRadius(12)
                }
            }

            if !ropeLibraryMessage.isEmpty {
                Text(ropeLibraryMessage)
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
        }
        .padding()
        .background(Color.gray.opacity(0.08))
        .cornerRadius(12)
    }


    func connectorInputView(
        title: String,
        presetId: Binding<String>,
        count: Binding<String>,
        isEnabled: Binding<Bool>
    ) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Toggle(title, isOn: isEnabled)
                .font(.headline)

            if isEnabled.wrappedValue {
                Picker("Тип соединителя", selection: presetId) {
                    ForEach(ConnectorCatalog.presets) { preset in
                        Text(preset.displayName).tag(preset.id)
                    }

                    ForEach(userConnectorPresets) { preset in
                        Text("★ \(preset.displayName)").tag("user:\(preset.id)")
                    }
                }
                .pickerStyle(.menu)

                Text(connectorPresetNote(presetId.wrappedValue))
                    .font(.caption)
                    .foregroundColor(.secondary)

                numberInputField("Количество, шт.", text: count)
            }
        }
        .padding()
        .background(Color.gray.opacity(0.08))
        .cornerRadius(12)
    }

    // MARK: - Логика

    func refreshUserBuoyPresets() {
        userBuoyPresets = UserBuoyStorage.loadAll()
    }

    func selectedUserBuoyId() -> String? {
        guard selectedBuoyPresetId.hasPrefix("user:") else {
            return nil
        }

        return String(selectedBuoyPresetId.dropFirst(5))
    }

    func selectedUserBuoy() -> UserBuoyDraft? {
        guard let id = selectedUserBuoyId() else {
            return nil
        }

        return userBuoyPresets.first { $0.id == id }
    }

    func selectedBuoyPreset() -> BuoyPreset? {
        if selectedBuoyPresetId == "manual" {
            return nil
        }

        if let userBuoy = selectedUserBuoy() {
            return userBuoy.asPreset
        }

        return BuoyCatalog.presets.first { $0.id == selectedBuoyPresetId }
    }

    func applySelectedBuoyPreset() {
        guard let preset = selectedBuoyPreset() else {
            return
        }

        selectedBuoyShape = preset.shape
        buoyDiameter = format(preset.diameterM)
        buoyHeight = format(preset.heightM)
        buoyCustomVolume = format(preset.customVolumeM3)
        buoyWeight = format(preset.weightKg)
        buoyDragCoefficient = format(preset.dragCoefficient)

        if let userBuoy = selectedUserBuoy() {
            customBuoyName = userBuoy.name
            let source = userBuoy.dataSource ?? .userInput
            buoySourceKind = source.kind
            buoySourceManufacturer = source.manufacturer
            buoySourceModel = source.model
            buoySourceDocument = source.document
            buoySourcePage = source.page
            buoySourceComment = source.comment
        }
    }

    func saveCurrentBuoyToLibrary() {
        let trimmedName = customBuoyName.trimmingCharacters(in: .whitespacesAndNewlines)
        let name = trimmedName.isEmpty ? "Пользовательский буй" : trimmedName

        let id = selectedUserBuoyId() ?? UUID().uuidString

        let buoy = UserBuoyDraft(
            id: id,
            name: name,
            type: "Пользовательский буй",
            shapeRawValue: selectedBuoyShape.rawValue,
            diameterM: number(buoyDiameter),
            heightM: number(buoyHeight),
            customVolumeM3: number(buoyCustomVolume),
            weightKg: number(buoyWeight),
            dragCoefficient: number(buoyDragCoefficient),
            note: "Пользовательский буй. Параметры введены вручную и сохранены в локальную библиотеку.",
            dataSource: makeDataSource(
                kind: buoySourceKind,
                manufacturer: buoySourceManufacturer,
                model: buoySourceModel,
                document: buoySourceDocument,
                page: buoySourcePage,
                comment: buoySourceComment
            )
        )

        UserBuoyStorage.upsert(buoy)
        refreshUserBuoyPresets()
        selectedBuoyPresetId = "user:\(buoy.id)"
        customBuoyName = buoy.name
        buoyLibraryMessage = "Буй сохранён в библиотеку: \(buoy.displayName)."
    }

    func deleteSelectedUserBuoy() {
        guard let id = selectedUserBuoyId() else {
            buoyLibraryMessage = "Выберите пользовательский буй для удаления."
            return
        }

        UserBuoyStorage.delete(id: id)
        refreshUserBuoyPresets()
        selectedBuoyPresetId = "manual"
        buoyLibraryMessage = "Пользовательский буй удалён. Параметры остались в форме как пользовательские значения."
    }



    func normalizeAssemblyItem(_ index: Int) {
        guard assemblyItems.indices.contains(index) else {
            return
        }

        let kind = MooringAssemblyItemKind(rawValue: assemblyItems[index].kindRawValue) ?? .line

        switch kind {
        case .connector:
            if selectedConnectorPreset(from: assemblyItems[index].presetId) == nil {
                assemblyItems[index].presetId = "shackle_55"
            }
            if assemblyItems[index].countText == "0" {
                assemblyItems[index].countText = "1"
            }

        case .line:
            if selectedRopePreset(from: assemblyItems[index].presetId) == nil {
                assemblyItems[index].presetId = "polyester_20"
            }
            if assemblyItems[index].lengthText == "0" {
                assemblyItems[index].lengthText = "10"
            }

        case .payload:
            if assemblyItems[index].weightAirText == "0" {
                assemblyItems[index].weightAirText = "10"
            }
            if assemblyItems[index].projectedAreaText == "0" {
                assemblyItems[index].projectedAreaText = "0.02"
            }
            if assemblyItems[index].dragCoefficientText == "0" {
                assemblyItems[index].dragCoefficientText = "1.0"
            }
        }
    }

    func addAssemblyItem() {
        switch selectedNewAssemblyKind {
        case .connector:
            assemblyItems.append(
                .connector(
                    title: "Новый соединитель",
                    presetId: "shackle_55",
                    countText: "1"
                )
            )
        case .line:
            assemblyItems.append(
                .line(
                    title: "Новый участок линии",
                    presetId: "polyester_20",
                    lengthText: "10"
                )
            )
        case .payload:
            assemblyItems.append(
                .payload(
                    title: "Новый прибор",
                    weightAirText: "10",
                    volumeText: "0",
                    projectedAreaText: "0.02",
                    dragCoefficientText: "1.0"
                )
            )
        }

        assemblyMessage = "Элемент добавлен в последовательность."
    }

    func deleteAssemblyItem(_ index: Int) {
        guard assemblyItems.indices.contains(index) else {
            return
        }

        assemblyItems.remove(at: index)
        assemblyMessage = "Элемент удалён из последовательности."
    }

    func moveAssemblyItemUp(_ index: Int) {
        guard index > 0, assemblyItems.indices.contains(index) else {
            return
        }

        assemblyItems.swapAt(index, index - 1)
    }

    func moveAssemblyItemDown(_ index: Int) {
        guard assemblyItems.indices.contains(index),
              index < assemblyItems.count - 1 else {
            return
        }

        assemblyItems.swapAt(index, index + 1)
    }

    func legacyAssemblyItemsFromCurrentFields() -> [MooringAssemblyItemDraft] {
        var items: [MooringAssemblyItemDraft] = []

        if useConnector1 {
            items.append(
                .connector(
                    title: "Соединитель 1",
                    presetId: selectedConnector1PresetId,
                    countText: connector1Count
                )
            )
        }

        items.append(
            .line(
                title: "Участок линии 1",
                presetId: selectedSegment1PresetId,
                lengthText: segment1Length
            )
        )

        if useConnector2 {
            items.append(
                .connector(
                    title: "Соединитель 2",
                    presetId: selectedConnector2PresetId,
                    countText: connector2Count
                )
            )
        }

        items.append(
            .payload(
                title: payloadName,
                weightAirText: payloadWeightAir,
                volumeText: payloadVolume,
                projectedAreaText: payloadProjectedArea,
                dragCoefficientText: payloadDragCoefficient
            )
        )

        if useSegment2 {
            items.append(
                .line(
                    title: "Участок линии 2",
                    presetId: selectedSegment2PresetId,
                    lengthText: segment2Length
                )
            )
        }

        if useConnector3 {
            items.append(
                .connector(
                    title: "Соединитель 3",
                    presetId: selectedConnector3PresetId,
                    countText: connector3Count
                )
            )
        }

        if useSegment3 {
            items.append(
                .line(
                    title: "Участок линии 3",
                    presetId: selectedSegment3PresetId,
                    lengthText: segment3Length
                )
            )
        }

        return items
    }

    func assemblySummary() -> String {
        var lines: [String] = []
        lines.append("Буй")

        for (index, item) in assemblyItems.enumerated() {
            guard item.isEnabled else {
                continue
            }

            let kind = item.kind

            switch kind {
            case .line:
                let preset = selectedRopePreset(from: item.presetId)
                let material = preset?.material ?? "линия"
                lines.append("\(index + 1). \(item.title): \(material), длина \(item.lengthText) м")

            case .connector:
                let preset = selectedConnectorPreset(from: item.presetId) ?? ConnectorCatalog.presetById(item.presetId)
                lines.append("\(index + 1). \(item.title): \(preset.type), \(item.countText) шт.")

            case .payload:
                lines.append("\(index + 1). \(item.title): прибор / нагрузка, масса \(item.weightAirText) кг")
            }
        }

        lines.append("Якорь")
        return lines.joined(separator: "\n")
    }


    func dataSourceDetails(_ source: ElementDataSource) -> String {
        var text = source.shortDescription

        if !source.comment.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            text += "\n  Комментарий: \(source.comment)"
        }

        return text
    }

    func currentBuoyDataSource() -> ElementDataSource {
        if let userBuoy = selectedUserBuoy() {
            return userBuoy.dataSource ?? .userInput
        }

        if selectedBuoyPresetId == "manual" {
            return makeDataSource(
                kind: buoySourceKind,
                manufacturer: buoySourceManufacturer,
                model: buoySourceModel,
                document: buoySourceDocument,
                page: buoySourcePage,
                comment: buoySourceComment
            )
        }

        return .educational
    }

    func currentAnchorDataSource() -> ElementDataSource {
        if let userAnchor = selectedUserAnchor() {
            return userAnchor.dataSource ?? .userInput
        }

        if selectedAnchorPresetId == "manual" {
            return makeDataSource(
                kind: anchorSourceKind,
                manufacturer: anchorSourceManufacturer,
                model: anchorSourceModel,
                document: anchorSourceDocument,
                page: anchorSourcePage,
                comment: anchorSourceComment
            )
        }

        return .educational
    }

    func ropeDataSource(for presetId: String) -> ElementDataSource {
        if let userRope = selectedUserRope(from: presetId) {
            return userRope.dataSource ?? .userInput
        }

        return .educational
    }

    func connectorDataSource(for presetId: String) -> ElementDataSource {
        if let userConnector = selectedUserConnector(from: presetId) {
            return userConnector.dataSource ?? .userInput
        }

        return .educational
    }

    func payloadDataSource() -> ElementDataSource {
        return .userInput
    }

    func sourceKindStatusLine(_ sources: [ElementDataSource]) -> String {
        let educationalCount = sources.filter { $0.kind == .educationalPreset }.count
        let userInputCount = sources.filter { $0.kind == .userInput }.count
        let manufacturerCount = sources.filter { $0.kind == .manufacturerData }.count
        let referenceCount = sources.filter { $0.kind == .engineeringReference }.count

        return """
        Учебные значения: \(educationalCount)
        Пользовательский ввод: \(userInputCount)
        Паспорт производителя: \(manufacturerCount)
        Инженерный источник: \(referenceCount)
        """
    }

    func dataSourcesReportSection() -> String {
        var lines: [String] = []
        var usedSources: [ElementDataSource] = []

        lines.append("## Источники данных элементов")
        lines.append("")
        lines.append("Этот раздел показывает происхождение параметров, использованных в расчёте. Источники не меняют расчёт, но помогают понять, какие значения являются учебными, пользовательскими или паспортными.")
        lines.append("")

        let buoySource = currentBuoyDataSource()
        usedSources.append(buoySource)
        lines.append("### Буй")
        lines.append("")
        lines.append("- Элемент: \(selectedBuoyPreset()?.displayName ?? customBuoyName)")
        lines.append("- Источник: \(dataSourceDetails(buoySource))")
        lines.append("")

        lines.append("### Последовательность постановки")
        lines.append("")

        for (index, item) in assemblyItems.enumerated() {
            guard item.isEnabled else {
                continue
            }

            switch item.kind {
            case .line:
                let preset = selectedRopePreset(from: item.presetId)
                let source = ropeDataSource(for: item.presetId)
                usedSources.append(source)

                lines.append("\(index + 1). \(item.title)")
                lines.append("   - Тип: Буйреп / линия")
                lines.append("   - Элемент: \(preset?.displayName ?? item.presetId)")
                lines.append("   - Длина: \(item.lengthText) м")
                lines.append("   - Источник: \(dataSourceDetails(source))")

            case .connector:
                let preset = selectedConnectorPreset(from: item.presetId)
                let source = connectorDataSource(for: item.presetId)
                usedSources.append(source)

                lines.append("\(index + 1). \(item.title)")
                lines.append("   - Тип: Соединитель")
                lines.append("   - Элемент: \(preset?.displayName ?? item.presetId)")
                lines.append("   - Количество: \(item.countText) шт.")
                lines.append("   - Источник: \(dataSourceDetails(source))")

            case .payload:
                let source = payloadDataSource()
                usedSources.append(source)

                lines.append("\(index + 1). \(item.title)")
                lines.append("   - Тип: Прибор / нагрузка")
                lines.append("   - Масса в воздухе: \(item.weightAirText) кг")
                lines.append("   - Источник: \(dataSourceDetails(source))")
            }

            lines.append("")
        }

        let anchorSource = currentAnchorDataSource()
        usedSources.append(anchorSource)
        lines.append("### Якорь")
        lines.append("")
        lines.append("- Элемент: \(anchorName)")
        lines.append("- Тип: \(anchorType)")
        lines.append("- Материал: \(anchorMaterial)")
        lines.append("- Источник: \(dataSourceDetails(anchorSource))")
        lines.append("")

        lines.append("### Грунт")
        lines.append("")
        lines.append("- Элемент: \(SeabedCatalog.presetById(selectedSeabedPresetId).displayName)")
        lines.append("- Источник: \(dataSourceDetails(.educational))")
        usedSources.append(.educational)
        lines.append("")

        lines.append("### Сводка по источникам")
        lines.append("")
        lines.append(sourceKindStatusLine(usedSources))

        if usedSources.contains(where: { $0.kind == .educationalPreset }) {
            lines.append("")
            lines.append("⚠️ В расчёте используются учебные значения. Для реального проектирования их необходимо заменить паспортными данными производителя или проверочным инженерным источником.")
        }

        return lines.joined(separator: "\n")
    }

    func refreshUserRopePresets() {
        userRopePresets = UserRopeStorage.loadAll()
    }

    func selectedUserRope(from presetId: String) -> UserRopeDraft? {
        guard presetId.hasPrefix("user:") else {
            return nil
        }

        let id = String(presetId.dropFirst(5))
        return userRopePresets.first { $0.id == id }
    }

    func selectedRopePreset(from presetId: String) -> RopePreset? {
        if let userRope = selectedUserRope(from: presetId) {
            return userRope.asPreset
        }

        return RopeCatalog.presets.first { $0.id == presetId }
    }

    func ropePresetNote(_ presetId: String) -> String {
        if let preset = selectedRopePreset(from: presetId) {
            return preset.note
        }

        if presetId.hasPrefix("user:") {
            return "Пользовательский участок не найден. Возможно, он был удалён из библиотеки."
        }

        return RopeCatalog.presetById(presetId).note
    }

    func applySelectedUserRopeToEditor() {
        guard !selectedUserRopeEditorId.isEmpty,
              let rope = userRopePresets.first(where: { $0.id == selectedUserRopeEditorId }) else {
            return
        }

        customRopeName = rope.name
        customRopeMaterial = rope.material
        customRopeDiameter = format(rope.diameterMm)
        customRopeBreakingLoad = format(rope.breakingLoadKn)
        customRopeWeightWater = format(rope.weightWaterKgM)
        customRopeDragCoefficient = format(rope.dragCoefficient)
        let source = rope.dataSource ?? .userInput
        ropeSourceKind = source.kind
        ropeSourceManufacturer = source.manufacturer
        ropeSourceModel = source.model
        ropeSourceDocument = source.document
        ropeSourcePage = source.page
        ropeSourceComment = source.comment
    }

    func saveCurrentRopeToLibrary() {
        let trimmedName = customRopeName.trimmingCharacters(in: .whitespacesAndNewlines)
        let name = trimmedName.isEmpty ? "Пользовательский участок линии" : trimmedName

        let trimmedMaterial = customRopeMaterial.trimmingCharacters(in: .whitespacesAndNewlines)
        let material = trimmedMaterial.isEmpty ? "Материал не задан" : trimmedMaterial

        let id = selectedUserRopeEditorId.isEmpty ? UUID().uuidString : selectedUserRopeEditorId

        let rope = UserRopeDraft(
            id: id,
            name: name,
            material: material,
            diameterMm: number(customRopeDiameter),
            breakingLoadKn: number(customRopeBreakingLoad),
            weightWaterKgM: number(customRopeWeightWater),
            dragCoefficient: number(customRopeDragCoefficient),
            note: "Пользовательский участок швартовной линии. Параметры введены вручную и сохранены в локальную библиотеку.",
            dataSource: makeDataSource(
                kind: ropeSourceKind,
                manufacturer: ropeSourceManufacturer,
                model: ropeSourceModel,
                document: ropeSourceDocument,
                page: ropeSourcePage,
                comment: ropeSourceComment
            )
        )

        UserRopeStorage.upsert(rope)
        refreshUserRopePresets()
        selectedUserRopeEditorId = rope.id
        ropeLibraryMessage = "Участок линии сохранён в библиотеку: \(rope.displayName)."
    }

    func deleteSelectedUserRope() {
        guard !selectedUserRopeEditorId.isEmpty else {
            ropeLibraryMessage = "Выберите пользовательский участок линии для удаления."
            return
        }

        let deletedId = selectedUserRopeEditorId
        UserRopeStorage.delete(id: deletedId)
        refreshUserRopePresets()
        selectedUserRopeEditorId = ""

        if selectedSegment1PresetId == "user:\(deletedId)" {
            selectedSegment1PresetId = "polyester_20"
        }

        if selectedSegment2PresetId == "user:\(deletedId)" {
            selectedSegment2PresetId = "chain_10"
        }

        if selectedSegment3PresetId == "user:\(deletedId)" {
            selectedSegment3PresetId = "steel_wire_8"
        }

        for index in assemblyItems.indices {
            if assemblyItems[index].presetId == "user:\(deletedId)" {
                assemblyItems[index].presetId = "polyester_20"
            }
        }

        ropeLibraryMessage = "Пользовательский участок линии удалён."
    }


    func refreshUserConnectorPresets() {
        userConnectorPresets = UserConnectorStorage.loadAll()
    }

    func selectedUserConnector(from presetId: String) -> UserConnectorDraft? {
        guard presetId.hasPrefix("user:") else {
            return nil
        }

        let id = String(presetId.dropFirst(5))
        return userConnectorPresets.first { $0.id == id }
    }

    func selectedConnectorPreset(from presetId: String) -> ConnectorPreset? {
        if let userConnector = selectedUserConnector(from: presetId) {
            return userConnector.asPreset
        }

        return ConnectorCatalog.presets.first { $0.id == presetId }
    }

    func connectorPresetNote(_ presetId: String) -> String {
        if let preset = selectedConnectorPreset(from: presetId) {
            return preset.note
        }

        if presetId.hasPrefix("user:") {
            return "Пользовательский соединитель не найден. Возможно, он был удалён из библиотеки."
        }

        return ConnectorCatalog.presetById(presetId).note
    }

    func applySelectedUserConnectorToEditor() {
        guard !selectedUserConnectorEditorId.isEmpty,
              let connector = userConnectorPresets.first(where: { $0.id == selectedUserConnectorEditorId }) else {
            return
        }

        customConnectorName = connector.name
        customConnectorType = connector.type
        customConnectorWeightAir = format(connector.weightAirKg)
        customConnectorVolume = format(connector.volumeM3)
        customConnectorBreakingLoad = format(connector.breakingLoadKn)
        customConnectorProjectedArea = format(connector.projectedAreaM2)
        customConnectorDragCoefficient = format(connector.dragCoefficient)
        let source = connector.dataSource ?? .userInput
        connectorSourceKind = source.kind
        connectorSourceManufacturer = source.manufacturer
        connectorSourceModel = source.model
        connectorSourceDocument = source.document
        connectorSourcePage = source.page
        connectorSourceComment = source.comment
    }

    func saveCurrentConnectorToLibrary() {
        let trimmedName = customConnectorName.trimmingCharacters(in: .whitespacesAndNewlines)
        let name = trimmedName.isEmpty ? "Пользовательский соединитель" : trimmedName

        let trimmedType = customConnectorType.trimmingCharacters(in: .whitespacesAndNewlines)
        let type = trimmedType.isEmpty ? "Соединитель" : trimmedType

        let id = selectedUserConnectorEditorId.isEmpty ? UUID().uuidString : selectedUserConnectorEditorId

        let connector = UserConnectorDraft(
            id: id,
            name: name,
            type: type,
            weightAirKg: number(customConnectorWeightAir),
            volumeM3: number(customConnectorVolume),
            breakingLoadKn: number(customConnectorBreakingLoad),
            projectedAreaM2: number(customConnectorProjectedArea),
            dragCoefficient: number(customConnectorDragCoefficient),
            note: "Пользовательский соединитель. Параметры введены вручную и сохранены в локальную библиотеку.",
            dataSource: makeDataSource(
                kind: connectorSourceKind,
                manufacturer: connectorSourceManufacturer,
                model: connectorSourceModel,
                document: connectorSourceDocument,
                page: connectorSourcePage,
                comment: connectorSourceComment
            )
        )

        UserConnectorStorage.upsert(connector)
        refreshUserConnectorPresets()
        selectedUserConnectorEditorId = connector.id
        connectorLibraryMessage = "Соединитель сохранён в библиотеку: \(connector.displayName)."
    }

    func deleteSelectedUserConnector() {
        guard !selectedUserConnectorEditorId.isEmpty else {
            connectorLibraryMessage = "Выберите пользовательский соединитель для удаления."
            return
        }

        let deletedId = selectedUserConnectorEditorId
        UserConnectorStorage.delete(id: deletedId)
        refreshUserConnectorPresets()
        selectedUserConnectorEditorId = ""

        for index in assemblyItems.indices {
            if assemblyItems[index].presetId == "user:\(deletedId)" && assemblyItems[index].kind == .connector {
                assemblyItems[index].presetId = "shackle_55"
            }
        }

        if selectedConnector1PresetId == "user:\(deletedId)" {
            selectedConnector1PresetId = "shackle_55"
        }

        if selectedConnector2PresetId == "user:\(deletedId)" {
            selectedConnector2PresetId = "swivel_60"
        }

        if selectedConnector3PresetId == "user:\(deletedId)" {
            selectedConnector3PresetId = "acoustic_release_35"
        }

        connectorLibraryMessage = "Пользовательский соединитель удалён."
    }

    func refreshUserAnchorPresets() {
        userAnchorPresets = UserAnchorStorage.loadAll()
    }

    func selectedUserAnchorId() -> String? {
        guard selectedAnchorPresetId.hasPrefix("user:") else {
            return nil
        }

        return String(selectedAnchorPresetId.dropFirst(5))
    }

    func selectedUserAnchor() -> UserAnchorDraft? {
        guard let id = selectedUserAnchorId() else {
            return nil
        }

        return userAnchorPresets.first { $0.id == id }
    }

    func selectedAnchorPreset() -> AnchorPreset? {
        if selectedAnchorPresetId == "manual" {
            return nil
        }

        if let userAnchor = selectedUserAnchor() {
            return userAnchor.asPreset
        }

        return AnchorCatalog.presets.first { $0.id == selectedAnchorPresetId }
    }

    func applySelectedAnchorPreset() {
        guard let preset = selectedAnchorPreset() else {
            return
        }

        anchorName = preset.name
        anchorType = preset.type
        anchorMaterial = preset.material
        anchorWeightAir = format(preset.weightAirKg)
        anchorVolume = format(preset.volumeM3)
        anchorBaseHoldingCoefficient = format(preset.baseHoldingCoefficient)

        if let userAnchor = selectedUserAnchor() {
            let source = userAnchor.dataSource ?? .userInput
            anchorSourceKind = source.kind
            anchorSourceManufacturer = source.manufacturer
            anchorSourceModel = source.model
            anchorSourceDocument = source.document
            anchorSourcePage = source.page
            anchorSourceComment = source.comment
        }
    }

    func saveCurrentAnchorToLibrary() {
        let trimmedName = anchorName.trimmingCharacters(in: .whitespacesAndNewlines)
        let name = trimmedName.isEmpty ? "Пользовательский якорь" : trimmedName

        let trimmedType = anchorType.trimmingCharacters(in: .whitespacesAndNewlines)
        let type = trimmedType.isEmpty ? "Пользовательский якорь" : trimmedType

        let trimmedMaterial = anchorMaterial.trimmingCharacters(in: .whitespacesAndNewlines)
        let material = trimmedMaterial.isEmpty ? "Материал не задан" : trimmedMaterial

        let id = selectedUserAnchorId() ?? UUID().uuidString

        let anchor = UserAnchorDraft(
            id: id,
            name: name,
            type: type,
            material: material,
            weightAirKg: number(anchorWeightAir),
            volumeM3: number(anchorVolume),
            baseHoldingCoefficient: number(anchorBaseHoldingCoefficient),
            note: "Пользовательский якорь. Параметры введены вручную и сохранены в локальную библиотеку.",
            dataSource: makeDataSource(
                kind: anchorSourceKind,
                manufacturer: anchorSourceManufacturer,
                model: anchorSourceModel,
                document: anchorSourceDocument,
                page: anchorSourcePage,
                comment: anchorSourceComment
            )
        )

        UserAnchorStorage.upsert(anchor)
        refreshUserAnchorPresets()
        selectedAnchorPresetId = "user:\(anchor.id)"
        anchorLibraryMessage = "Якорь сохранён в библиотеку: \(anchor.displayName)."
    }

    func deleteSelectedUserAnchor() {
        guard let id = selectedUserAnchorId() else {
            anchorLibraryMessage = "Выберите пользовательский якорь для удаления."
            return
        }

        UserAnchorStorage.delete(id: id)
        refreshUserAnchorPresets()
        selectedAnchorPresetId = "manual"
        anchorLibraryMessage = "Пользовательский якорь удалён. Параметры остались в форме как пользовательские значения."
    }

    func makeSegment(presetId: String, lengthText: String) -> MooringSegment {
        let preset = selectedRopePreset(from: presetId) ?? RopeCatalog.presetById(presetId)

        return MooringSegment(
            name: preset.name,
            material: preset.material,
            diameterMm: preset.diameterMm,
            lengthM: number(lengthText),
            breakingLoadKn: preset.breakingLoadKn,
            weightWaterKgM: preset.weightWaterKgM,
            dragCoefficient: preset.dragCoefficient
        )
    }

    func makeMooringLine() -> MooringLine {
        var segments: [MooringSegment] = []

        for item in assemblyItems where item.isEnabled && item.kind == .line {
            segments.append(
                makeSegment(
                    presetId: item.presetId,
                    lengthText: item.lengthText
                )
            )
        }

        segments = segments.filter { $0.lengthM > 0 }

        return MooringLine(segments: segments)
    }

    func makeConnector(presetId: String, countText: String) -> ConnectorElement {
        let preset = selectedConnectorPreset(from: presetId) ?? ConnectorCatalog.presetById(presetId)

        return ConnectorElement(
            name: preset.name,
            type: preset.type,
            count: max(Int(number(countText)), 0),
            weightAirKg: preset.weightAirKg,
            volumeM3: preset.volumeM3,
            breakingLoadKn: preset.breakingLoadKn,
            projectedAreaM2: preset.projectedAreaM2,
            dragCoefficient: preset.dragCoefficient
        )
    }

    func makeConnectorSet() -> ConnectorSet {
        var elements: [ConnectorElement] = []

        for item in assemblyItems where item.isEnabled && item.kind == .connector {
            elements.append(
                makeConnector(
                    presetId: item.presetId,
                    countText: item.countText
                )
            )
        }

        elements = elements.filter { $0.count > 0 }

        return ConnectorSet(elements: elements)
    }

    func makePayload() -> Payload {
        let payloadItems = assemblyItems.filter {
            $0.isEnabled && $0.kind == .payload
        }

        if payloadItems.isEmpty {
            return Payload(
                name: "Нет приборов",
                weightAirKg: 0,
                volumeM3: 0,
                projectedAreaM2: 0,
                dragCoefficient: 1.0
            )
        }

        let totalWeight = payloadItems.reduce(0.0) { $0 + number($1.weightAirText) }
        let totalVolume = payloadItems.reduce(0.0) { $0 + number($1.volumeText) }
        let totalArea = payloadItems.reduce(0.0) { $0 + number($1.projectedAreaText) }

        let weightedCdSum = payloadItems.reduce(0.0) { partial, item in
            partial + number(item.projectedAreaText) * number(item.dragCoefficientText)
        }

        let averageCd = totalArea > 0 ? weightedCdSum / totalArea : 1.0
        let names = payloadItems.map { $0.title }.joined(separator: ", ")

        return Payload(
            name: names.isEmpty ? "Приборы" : names,
            weightAirKg: totalWeight,
            volumeM3: totalVolume,
            projectedAreaM2: totalArea,
            dragCoefficient: averageCd
        )
    }

    func makeDraft() -> BuoyCalcDraft {
        return BuoyCalcDraft(
            projectName: projectName,
            waterDensity: waterDensity,
            depth: depth,
            currentSpeed: currentSpeed,
            waveHeight: waveHeight,
            wavePeriod: wavePeriod,
            selectedSeabedPresetId: selectedSeabedPresetId,
            selectedBuoyPresetId: selectedBuoyPresetId,
            selectedBuoyShapeRawValue: selectedBuoyShape.rawValue,
            buoyDiameter: buoyDiameter,
            buoyHeight: buoyHeight,
            buoyCustomVolume: buoyCustomVolume,
            buoyWeight: buoyWeight,
            buoyDragCoefficient: buoyDragCoefficient,
            systemSafetyFactor: systemSafetyFactor,
            mooringAssemblyItems: assemblyItems,
            selectedSegment1PresetId: selectedSegment1PresetId,
            segment1Length: segment1Length,
            useSegment2: useSegment2,
            selectedSegment2PresetId: selectedSegment2PresetId,
            segment2Length: segment2Length,
            useSegment3: useSegment3,
            selectedSegment3PresetId: selectedSegment3PresetId,
            segment3Length: segment3Length,
            useConnector1: useConnector1,
            selectedConnector1PresetId: selectedConnector1PresetId,
            connector1Count: connector1Count,
            useConnector2: useConnector2,
            selectedConnector2PresetId: selectedConnector2PresetId,
            connector2Count: connector2Count,
            useConnector3: useConnector3,
            selectedConnector3PresetId: selectedConnector3PresetId,
            connector3Count: connector3Count,
            payloadName: payloadName,
            payloadWeightAir: payloadWeightAir,
            payloadVolume: payloadVolume,
            payloadProjectedArea: payloadProjectedArea,
            payloadDragCoefficient: payloadDragCoefficient,
            selectedAnchorPresetId: selectedAnchorPresetId,
            anchorName: anchorName,
            anchorType: anchorType,
            anchorMaterial: anchorMaterial,
            anchorWeightAir: anchorWeightAir,
            anchorVolume: anchorVolume,
            anchorBaseHoldingCoefficient: anchorBaseHoldingCoefficient
        )
    }

    func applyDraft(_ draft: BuoyCalcDraft) {
        projectName = draft.projectName

        waterDensity = draft.waterDensity
        depth = draft.depth
        currentSpeed = draft.currentSpeed
        waveHeight = draft.waveHeight
        wavePeriod = draft.wavePeriod
        selectedSeabedPresetId = draft.selectedSeabedPresetId

        selectedBuoyPresetId = draft.selectedBuoyPresetId ?? "manual"

        selectedBuoyShape = BuoyShape(rawValue: draft.selectedBuoyShapeRawValue) ?? .cylinder
        buoyDiameter = draft.buoyDiameter
        buoyHeight = draft.buoyHeight
        buoyCustomVolume = draft.buoyCustomVolume
        buoyWeight = draft.buoyWeight
        buoyDragCoefficient = draft.buoyDragCoefficient

        systemSafetyFactor = draft.systemSafetyFactor

        selectedSegment1PresetId = draft.selectedSegment1PresetId
        segment1Length = draft.segment1Length

        useSegment2 = draft.useSegment2
        selectedSegment2PresetId = draft.selectedSegment2PresetId
        segment2Length = draft.segment2Length

        useSegment3 = draft.useSegment3
        selectedSegment3PresetId = draft.selectedSegment3PresetId
        segment3Length = draft.segment3Length

        useConnector1 = draft.useConnector1
        selectedConnector1PresetId = draft.selectedConnector1PresetId
        connector1Count = draft.connector1Count

        useConnector2 = draft.useConnector2
        selectedConnector2PresetId = draft.selectedConnector2PresetId
        connector2Count = draft.connector2Count

        useConnector3 = draft.useConnector3
        selectedConnector3PresetId = draft.selectedConnector3PresetId
        connector3Count = draft.connector3Count

        payloadName = draft.payloadName
        payloadWeightAir = draft.payloadWeightAir
        payloadVolume = draft.payloadVolume
        payloadProjectedArea = draft.payloadProjectedArea
        payloadDragCoefficient = draft.payloadDragCoefficient

        if let savedAssemblyItems = draft.mooringAssemblyItems {
            assemblyItems = savedAssemblyItems
        } else {
            assemblyItems = legacyAssemblyItemsFromCurrentFields()
        }

        selectedAnchorPresetId = draft.selectedAnchorPresetId
        anchorName = draft.anchorName ?? AnchorCatalog.presetById(selectedAnchorPresetId).name
        anchorType = draft.anchorType ?? AnchorCatalog.presetById(selectedAnchorPresetId).type
        anchorMaterial = draft.anchorMaterial ?? AnchorCatalog.presetById(selectedAnchorPresetId).material
        anchorWeightAir = draft.anchorWeightAir
        anchorVolume = draft.anchorVolume
        anchorBaseHoldingCoefficient = draft.anchorBaseHoldingCoefficient

        lastResult = nil
        reportText = "Отчёт будет сформирован после расчёта."
        reportPDFData = Data()
        resultText = "Проект загружен. Нажмите «Рассчитать», чтобы обновить результат."
    }

    func refreshSavedProjects() {
        savedProjects = ProjectStorage.loadAll()

        if !selectedSavedProjectId.isEmpty &&
            !savedProjects.contains(where: { $0.id == selectedSavedProjectId }) {
            selectedSavedProjectId = ""
        }
    }

    func saveCurrentProject() {
        let draft = makeDraft()
        let projectId = selectedSavedProjectId.isEmpty ? UUID().uuidString : selectedSavedProjectId
        let displayName = projectName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? "Без названия" : projectName

        let savedProject = SavedBuoyCalcProject(
            id: projectId,
            name: displayName,
            updatedAt: Date(),
            draft: draft
        )

        ProjectStorage.upsert(savedProject)
        refreshSavedProjects()
        selectedSavedProjectId = savedProject.id
        storageMessage = "Проект сохранён: \(savedProject.displayName)."
    }

    func loadSelectedProject() {
        guard let project = savedProjects.first(where: { $0.id == selectedSavedProjectId }) else {
            storageMessage = "Выберите проект для загрузки."
            return
        }

        applyDraft(project.draft)
        selectedSavedProjectId = project.id
        storageMessage = "Проект загружен: \(project.displayName)."
    }

    func deleteSelectedProject() {
        guard !selectedSavedProjectId.isEmpty else {
            storageMessage = "Выберите проект для удаления."
            return
        }

        ProjectStorage.delete(id: selectedSavedProjectId)
        selectedSavedProjectId = ""
        refreshSavedProjects()
        storageMessage = "Проект удалён."
    }

    func startNewProject() {
        selectedSavedProjectId = ""
        projectName = "Новый проект"
        lastResult = nil
        reportText = "Отчёт будет сформирован после расчёта."
        reportPDFData = Data()
        resultText = "Новый проект создан. Введите данные и нажмите «Рассчитать»."
        storageMessage = "Создан новый проект. Старые сохранённые проекты не изменены."
    }

    func calculate() {

        let selectedSeabedPreset = SeabedCatalog.presetById(selectedSeabedPresetId)

        let environment = Environment(
            waterDensityKgM3: number(waterDensity),
            depthM: number(depth),
            currentSpeedMS: number(currentSpeed),
            waveHeightM: number(waveHeight),
            wavePeriodS: number(wavePeriod),
            seabed: selectedSeabedPreset
        )

        let buoy = Buoy(
            shape: selectedBuoyShape,
            diameterM: number(buoyDiameter),
            heightM: number(buoyHeight),
            customVolumeM3: number(buoyCustomVolume),
            weightKg: number(buoyWeight),
            dragCoefficient: number(buoyDragCoefficient)
        )

        let mooringLine = makeMooringLine()
        let connectorSet = makeConnectorSet()

        let payload = makePayload()

        let anchor = Anchor(
            name: anchorName,
            type: anchorType,
            material: anchorMaterial,
            weightAirKg: number(anchorWeightAir),
            volumeM3: number(anchorVolume),
            baseHoldingCoefficient: number(anchorBaseHoldingCoefficient)
        )

        let project = BuoyProject(
            name: projectName,
            environment: environment,
            buoy: buoy,
            mooringLine: mooringLine,
            connectors: connectorSet,
            payload: payload,
            anchor: anchor,
            safetyFactor: number(systemSafetyFactor)
        )

        let result = project.calculate()
        lastResult = result

        let generatedReportText = ReportBuilder.makeReport(
            project: project,
            result: result,
            mooringLine: mooringLine,
            connectors: connectorSet,
            environment: environment,
            buoy: buoy,
            payload: payload,
            anchor: anchor
        )

        let reportWithAssembly = generatedReportText + "\n\n---\n\n## Последовательность постановки\n\n" + assemblySummary()
        let reportWithSources = reportWithAssembly + "\n\n---\n\n" + dataSourcesReportSection()
        reportText = reportWithSources

        reportPDFData = PDFReportExporter.makePDFData(
            projectName: project.name,
            project: project,
            result: result,
            reportText: reportWithSources,
            mooringLine: mooringLine,
            connectors: connectorSet,
            environment: environment,
            buoy: buoy,
            payload: payload,
            anchor: anchor,
            assemblyItems: assemblyItems,
            buoyTitle: selectedBuoyPreset()?.displayName ?? customBuoyName,
            anchorTitle: anchorName,
            depthM: number(depth),
            lineLengthM: result.mooringLineLengthM,
            estimatedOffsetM: result.estimatedCurrentOffsetM,
            maxOffsetM: result.maxGeometricOffsetM,
            currentSpeedMS: number(currentSpeed)
        )

        resultText = """
        Проект: \(project.name)

        Условия:
        Грунт: \(selectedSeabedPreset.name)
        Множитель грунта: \(format(selectedSeabedPreset.holdingMultiplier))

        Форма буя: \(buoy.shape.rawValue)
        Объём буя: \(format(result.buoyVolumeM3)) м³
        Полная плавучесть: \(format(result.grossBuoyancyKg)) кг

        Буй:
        Площадь сопротивления буя: \(format(result.buoyProjectedAreaM2)) м²
        Сила течения на буй: \(format(result.buoyCurrentForceN)) Н

        Последовательность постановки:
        \(assemblySummary())

        Источники данных:
        Подробная сводка источников добавлена в текстовый отчёт и PDF.

        Швартовная линия:
        \(mooringLine.segmentSummary())

        Суммарная длина линии: \(format(result.mooringLineLengthM)) м
        Вес линии в воде: \(format(result.mooringLineWeightInWaterKg)) кг
        Площадь сопротивления линии: \(format(result.mooringLineProjectedAreaM2)) м²
        Сила течения на линию: \(format(result.mooringLineCurrentForceN)) Н

        Соединители:
        \(connectorSet.summary())

        Вес соединителей в воде: \(format(result.connectorWeightInWaterKg)) кг
        Площадь сопротивления соединителей: \(format(result.connectorProjectedAreaM2)) м²
        Сила течения на соединители: \(format(result.connectorCurrentForceN)) Н

        Минимальная разрывная нагрузка линии: \(format(result.mooringLineMinimumBreakingLoadKn)) кН
        Минимальная разрывная нагрузка соединителей: \(format(result.connectorMinimumBreakingLoadKn)) кН
        Минимальная разрывная нагрузка системы: \(format(result.systemMinimumBreakingLoadKn)) кН
        Рабочая нагрузка системы: \(format(result.systemWorkingLoadKn)) кН
        Расчётное натяжение системы: \(format(result.estimatedLineTensionKn)) кН
        Запас по натяжению: \(format(result.tensionSafetyRatio))

        Прибор: \(payload.name)
        Масса прибора в воздухе: \(format(payload.weightAirKg)) кг
        Объём прибора: \(format(payload.volumeM3)) м³
        Вес прибора в воде: \(format(result.payloadWeightInWaterKg)) кг
        Площадь сопротивления прибора: \(format(result.payloadProjectedAreaM2)) м²
        Сила течения на прибор: \(format(result.payloadCurrentForceN)) Н

        Суммарная сила течения: \(format(result.totalCurrentForceN)) Н
        Суммарная сила течения: \(format(result.totalCurrentForceKn)) кН

        Волна:
        Высота волны: \(format(environment.waveHeightM)) м
        Период волны: \(format(environment.wavePeriodS)) с
        Орбитальная скорость волны: \(format(result.waveOrbitalVelocityMS)) м/с
        Волновая сила на буй: \(format(result.buoyWaveForceN)) Н

        Суммарная горизонтальная сила: \(format(result.totalHorizontalForceN)) Н
        Суммарная горизонтальная сила: \(format(result.totalHorizontalForceKn)) кН

        Общая вертикальная нагрузка: \(format(result.totalVerticalLoadKg)) кг
        Запас плавучести: \(format(result.buoyancyReserveKg)) кг

        Якорь: \(anchor.type)
        Материал якоря: \(anchor.material)
        Масса якоря в воде: \(format(result.anchorWeightInWaterKg)) кг
        Эффективный коэффициент удержания: \(format(result.anchorEffectiveHoldingCoefficient))
        Удерживающая способность якоря: \(format(result.anchorHoldingCapacityKn)) кН
        Требуемое удержание: \(format(result.requiredHoldingKn)) кН
        Запас удержания якоря: \(format(result.anchorSafetyRatio))

        Максимальный геометрический снос: \(format(result.maxGeometricOffsetM)) м
        Расчётный снос по течению: \(format(result.estimatedCurrentOffsetM)) м

        Геометрический угол линии: \(format(result.mooringAngleDeg))°
        Угол от соотношения сил: \(format(result.forceAngleDeg))°

        Статус:
        \(result.status.title)

        Комментарии:
        \(result.messages.joined(separator: "\n"))
        """
    }

    func number(_ text: String) -> Double {
        let normalized = text.replacingOccurrences(of: ",", with: ".")
        return Double(normalized) ?? 0
    }

    func format(_ value: Double) -> String {
        return String(format: "%.2f", value)
    }
}

#Preview {
    ContentView()
}
