import SwiftUI

// MARK: - Библиотека элементов

struct LibraryView: View {

    @State private var userBuoyPresets: [UserBuoyDraft] = []
    @State private var userRopePresets: [UserRopeDraft] = []
    @State private var userConnectorPresets: [UserConnectorDraft] = []
    @State private var userAnchorPresets: [UserAnchorDraft] = []

    var body: some View {
        NavigationStack {
            List {
                buoySection
                userBuoySection
                ropeSection
                userRopeSection
                connectorSection
                userConnectorSection
                anchorSection
                userAnchorSection
                seabedSection
            }
            .navigationTitle("Библиотека")
            .onAppear {
                userBuoyPresets = UserBuoyStorage.loadAll()
                userRopePresets = UserRopeStorage.loadAll()
                userConnectorPresets = UserConnectorStorage.loadAll()
                userAnchorPresets = UserAnchorStorage.loadAll()
            }
        }
    }

    // MARK: - Буи

    var buoySection: some View {
        Section("Буи") {
            ForEach(BuoyCatalog.presets) { preset in
                VStack(alignment: .leading, spacing: 6) {
                    Text(preset.displayName)
                        .font(.headline)

                    valueRow("Название", preset.name)
                    valueRow("Форма", preset.shape.rawValue)
                    valueRow("Диаметр / ширина", "\(format(preset.diameterM)) м")
                    valueRow("Высота", "\(format(preset.heightM)) м")
                    valueRow("Паспортный объём", "\(format(preset.customVolumeM3)) м³")
                    valueRow("Масса", "\(format(preset.weightKg)) кг")
                    valueRow("Cd", format(preset.dragCoefficient))

                    Text(preset.note)
                        .font(.caption)
                        .foregroundColor(.secondary)
                        .padding(.top, 4)

                    sourceRows(.educational)
                }
                .padding(.vertical, 6)
            }
        }
    }



    var userBuoySection: some View {
        Section("Пользовательские буи") {
            if userBuoyPresets.isEmpty {
                Text("Пользовательских буёв пока нет. Их можно добавить во вкладке «Элементы» в разделе «Буй».")
                    .font(.caption)
                    .foregroundColor(.secondary)
            } else {
                ForEach(userBuoyPresets) { preset in
                    VStack(alignment: .leading, spacing: 6) {
                        Text(preset.displayName)
                            .font(.headline)

                        valueRow("Тип", preset.type)
                        valueRow("Форма", preset.shape.rawValue)
                        valueRow("Диаметр / ширина", "\(format(preset.diameterM)) м")
                        valueRow("Высота", "\(format(preset.heightM)) м")
                        valueRow("Паспортный объём", "\(format(preset.customVolumeM3)) м³")
                        valueRow("Масса", "\(format(preset.weightKg)) кг")
                        valueRow("Cd", format(preset.dragCoefficient))

                        Text(preset.note)
                            .font(.caption)
                            .foregroundColor(.secondary)
                            .padding(.top, 4)

                        sourceRows(preset.dataSource ?? .userInput)
                    }
                    .padding(.vertical, 6)
                }
            }
        }
    }


    // MARK: - Буйрепы / участки линии

    var ropeSection: some View {
        Section("Участки швартовной линии") {
            ForEach(RopeCatalog.presets) { preset in
                VStack(alignment: .leading, spacing: 6) {
                    Text(preset.displayName)
                        .font(.headline)

                    valueRow("Название", preset.name)
                    valueRow("Разрывная нагрузка", "\(format(preset.breakingLoadKn)) кН")
                    valueRow("Вес в воде", "\(format(preset.weightWaterKgM)) кг/м")
                    valueRow("Cd", format(preset.dragCoefficient))

                    Text(preset.note)
                        .font(.caption)
                        .foregroundColor(.secondary)
                        .padding(.top, 4)

                    sourceRows(.educational)
                }
                .padding(.vertical, 6)
            }
        }
    }



    var userRopeSection: some View {
        Section("Пользовательские участки швартовной линии") {
            if userRopePresets.isEmpty {
                Text("Пользовательских участков линии пока нет. Их можно добавить во вкладке «Элементы» в разделе «Швартовная линия».")
                    .font(.caption)
                    .foregroundColor(.secondary)
            } else {
                ForEach(userRopePresets) { preset in
                    VStack(alignment: .leading, spacing: 6) {
                        Text(preset.displayName)
                            .font(.headline)

                        valueRow("Материал", preset.material)
                        valueRow("Диаметр", "\(format(preset.diameterMm)) мм")
                        valueRow("Разрывная нагрузка", "\(format(preset.breakingLoadKn)) кН")
                        valueRow("Вес в воде", "\(format(preset.weightWaterKgM)) кг/м")
                        valueRow("Cd", format(preset.dragCoefficient))

                        Text(preset.note)
                            .font(.caption)
                            .foregroundColor(.secondary)
                            .padding(.top, 4)

                        sourceRows(preset.dataSource ?? .userInput)
                    }
                    .padding(.vertical, 6)
                }
            }
        }
    }


    // MARK: - Соединители

    var connectorSection: some View {
        Section("Соединительные элементы") {
            ForEach(ConnectorCatalog.presets) { preset in
                VStack(alignment: .leading, spacing: 6) {
                    Text(preset.displayName)
                        .font(.headline)

                    valueRow("Название", preset.name)
                    valueRow("Масса в воздухе", "\(format(preset.weightAirKg)) кг")
                    valueRow("Объём", "\(format(preset.volumeM3)) м³")
                    valueRow("Разрывная нагрузка", "\(format(preset.breakingLoadKn)) кН")
                    valueRow("Площадь сопротивления", "\(format(preset.projectedAreaM2)) м²")
                    valueRow("Cd", format(preset.dragCoefficient))

                    Text(preset.note)
                        .font(.caption)
                        .foregroundColor(.secondary)
                        .padding(.top, 4)

                    sourceRows(.educational)
                }
                .padding(.vertical, 6)
            }
        }
    }



    var userConnectorSection: some View {
        Section("Пользовательские соединители") {
            if userConnectorPresets.isEmpty {
                Text("Пользовательских соединителей пока нет. Их можно добавить во вкладке «Элементы» в разделе «Последовательность постановки».")
                    .font(.caption)
                    .foregroundColor(.secondary)
            } else {
                ForEach(userConnectorPresets) { preset in
                    VStack(alignment: .leading, spacing: 6) {
                        Text(preset.displayName)
                            .font(.headline)

                        valueRow("Тип", preset.type)
                        valueRow("Масса в воздухе", "\(format(preset.weightAirKg)) кг")
                        valueRow("Объём", "\(format(preset.volumeM3)) м³")
                        valueRow("Разрывная нагрузка", "\(format(preset.breakingLoadKn)) кН")
                        valueRow("Площадь сопротивления", "\(format(preset.projectedAreaM2)) м²")
                        valueRow("Cd", format(preset.dragCoefficient))

                        Text(preset.note)
                            .font(.caption)
                            .foregroundColor(.secondary)
                            .padding(.top, 4)

                        sourceRows(preset.dataSource ?? .userInput)
                    }
                    .padding(.vertical, 6)
                }
            }
        }
    }


    // MARK: - Якоря

    var anchorSection: some View {
        Section("Якоря") {
            ForEach(AnchorCatalog.presets) { preset in
                VStack(alignment: .leading, spacing: 6) {
                    Text(preset.displayName)
                        .font(.headline)

                    valueRow("Название", preset.name)
                    valueRow("Тип", preset.type)
                    valueRow("Материал", preset.material)
                    valueRow("Масса в воздухе", "\(format(preset.weightAirKg)) кг")
                    valueRow("Объём", "\(format(preset.volumeM3)) м³")
                    valueRow("Базовый коэффициент удержания", format(preset.baseHoldingCoefficient))

                    Text(preset.note)
                        .font(.caption)
                        .foregroundColor(.secondary)
                        .padding(.top, 4)

                    sourceRows(.educational)
                }
                .padding(.vertical, 6)
            }
        }
    }



    var userAnchorSection: some View {
        Section("Пользовательские якоря") {
            if userAnchorPresets.isEmpty {
                Text("Пользовательских якорей пока нет. Их можно добавить во вкладке «Элементы» в разделе «Якорь».")
                    .font(.caption)
                    .foregroundColor(.secondary)
            } else {
                ForEach(userAnchorPresets) { preset in
                    VStack(alignment: .leading, spacing: 6) {
                        Text(preset.displayName)
                            .font(.headline)

                        valueRow("Тип", preset.type)
                        valueRow("Материал", preset.material)
                        valueRow("Масса в воздухе", "\(format(preset.weightAirKg)) кг")
                        valueRow("Объём", "\(format(preset.volumeM3)) м³")
                        valueRow("Базовый коэффициент удержания", format(preset.baseHoldingCoefficient))

                        Text(preset.note)
                            .font(.caption)
                            .foregroundColor(.secondary)
                            .padding(.top, 4)

                        sourceRows(preset.dataSource ?? .userInput)
                    }
                    .padding(.vertical, 6)
                }
            }
        }
    }


    // MARK: - Грунты

    var seabedSection: some View {
        Section("Типы грунта") {
            ForEach(SeabedCatalog.presets) { preset in
                VStack(alignment: .leading, spacing: 6) {
                    Text(preset.displayName)
                        .font(.headline)

                    valueRow("Множитель удержания", format(preset.holdingMultiplier))

                    Text(preset.note)
                        .font(.caption)
                        .foregroundColor(.secondary)
                        .padding(.top, 4)

                    sourceRows(.educational)
                }
                .padding(.vertical, 6)
            }
        }
    }

    // MARK: - Helpers

    func sourceRows(_ source: ElementDataSource) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            valueRow("Источник", source.shortDescription)

            if !source.comment.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                Text(source.comment)
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
        }
        .padding(.top, 4)
    }

    func valueRow(_ title: String, _ value: String) -> some View {
        HStack(alignment: .top) {
            Text(title)
                .font(.caption)
                .foregroundColor(.secondary)

            Spacer()

            Text(value)
                .font(.caption)
                .multilineTextAlignment(.trailing)
        }
    }

    func format(_ value: Double) -> String {
        if value.isNaN || value.isInfinite {
            return "—"
        }

        if abs(value) >= 100 {
            return String(format: "%.0f", value)
        }

        if abs(value) < 0.01 && value != 0 {
            return String(format: "%.5f", value)
        }

        return String(format: "%.2f", value)
    }
}

#Preview {
    LibraryView()
}
