import SwiftUI

// MARK: - Статус отдельной проверки

enum CheckStatus {
    case ok
    case warning
    case failed

    var title: String {
        switch self {
        case .ok:
            return "OK"
        case .warning:
            return "WARNING"
        case .failed:
            return "FAILED"
        }
    }

    var icon: String {
        switch self {
        case .ok:
            return "✅"
        case .warning:
            return "⚠️"
        case .failed:
            return "❌"
        }
    }

    var color: Color {
        switch self {
        case .ok:
            return .green
        case .warning:
            return .orange
        case .failed:
            return .red
        }
    }
}

// MARK: - Одна проверка системы

struct SystemCheckItem: Identifiable {
    let id = UUID()

    var name: String
    var status: CheckStatus
    var fact: String
    var requirement: String
    var recommendation: String
}

// MARK: - Таблица проверок системы

struct SystemChecksView: View {
    var result: CalculationResult
    var depthM: Double
    var lineLengthM: Double

    var checks: [SystemCheckItem] {
        makeChecks()
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Проверки системы")
                .font(.headline)

            Text("Быстрая проверка ключевых ограничений расчёта.")
                .font(.caption)
                .foregroundColor(.secondary)

            ForEach(checks) { check in
                checkCard(check)
            }
        }
        .padding()
        .background(Color.gray.opacity(0.08))
        .cornerRadius(16)
    }

    func checkCard(_ check: SystemCheckItem) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(alignment: .center) {
                Text(check.status.icon)

                Text(check.name)
                    .font(.headline)

                Spacer()

                Text(check.status.title)
                    .font(.caption)
                    .bold()
                    .padding(.horizontal, 8)
                    .padding(.vertical, 4)
                    .background(check.status.color.opacity(0.18))
                    .foregroundColor(check.status.color)
                    .cornerRadius(8)
            }

            Divider()

            VStack(alignment: .leading, spacing: 4) {
                labelValue("Факт", check.fact)
                labelValue("Ориентир", check.requirement)

                if !check.recommendation.isEmpty {
                    labelValue("Что сделать", check.recommendation)
                }
            }
        }
        .padding()
        .background(Color.white.opacity(0.65))
        .cornerRadius(12)
    }

    func labelValue(_ label: String, _ value: String) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(label)
                .font(.caption2)
                .foregroundColor(.secondary)

            Text(value)
                .font(.caption)
        }
    }

    func makeChecks() -> [SystemCheckItem] {
        [
            buoyancyCheck(),
            lineLengthCheck(),
            tensionCheck(),
            anchorCheck(),
            offsetCheck(),
            weakLinkCheck()
        ]
    }

    func buoyancyCheck() -> SystemCheckItem {
        if result.buoyancyReserveKg <= 0 {
            return SystemCheckItem(
                name: "Плавучесть",
                status: .failed,
                fact: "Запас плавучести \(format(result.buoyancyReserveKg)) кг",
                requirement: "Запас должен быть больше 0 кг",
                recommendation: "Увеличьте объём буя или уменьшите массу подвешенной системы."
            )
        }

        if result.buoyancyReserveKg < result.totalVerticalLoadKg * 0.2 {
            return SystemCheckItem(
                name: "Плавучесть",
                status: .warning,
                fact: "Запас плавучести \(format(result.buoyancyReserveKg)) кг",
                requirement: "Желательно больше 20% от вертикальной нагрузки",
                recommendation: "Желательно увеличить запас плавучести."
            )
        }

        return SystemCheckItem(
            name: "Плавучесть",
            status: .ok,
            fact: "Запас плавучести \(format(result.buoyancyReserveKg)) кг",
            requirement: "Больше 20% от вертикальной нагрузки",
            recommendation: ""
        )
    }

    func lineLengthCheck() -> SystemCheckItem {
        if lineLengthM < depthM {
            return SystemCheckItem(
                name: "Длина линии",
                status: .failed,
                fact: "Длина линии \(format(lineLengthM)) м",
                requirement: "Должна быть не меньше глубины \(format(depthM)) м",
                recommendation: "Увеличьте длину швартовной линии."
            )
        }

        return SystemCheckItem(
            name: "Длина линии",
            status: .ok,
            fact: "Длина линии \(format(lineLengthM)) м",
            requirement: "Не меньше глубины \(format(depthM)) м",
            recommendation: ""
        )
    }

    func tensionCheck() -> SystemCheckItem {
        if result.systemWorkingLoadKn <= 0 {
            return SystemCheckItem(
                name: "Натяжение",
                status: .failed,
                fact: "Рабочая нагрузка системы не определена",
                requirement: "Рабочая нагрузка должна быть больше расчётного натяжения",
                recommendation: "Проверьте разрывные нагрузки линии и соединителей."
            )
        }

        if result.estimatedLineTensionKn > result.systemWorkingLoadKn {
            return SystemCheckItem(
                name: "Натяжение",
                status: .failed,
                fact: "Натяжение \(format(result.estimatedLineTensionKn)) кН > WLL \(format(result.systemWorkingLoadKn)) кН",
                requirement: "Натяжение должно быть меньше рабочей нагрузки",
                recommendation: "Увеличьте прочность самого слабого элемента."
            )
        }

        if result.tensionSafetyRatio < 1.5 {
            return SystemCheckItem(
                name: "Натяжение",
                status: .warning,
                fact: "Запас по натяжению \(format(result.tensionSafetyRatio))",
                requirement: "Желательно не меньше 1.5",
                recommendation: "Увеличьте прочность линии или соединителей."
            )
        }

        return SystemCheckItem(
            name: "Натяжение",
            status: .ok,
            fact: "Запас по натяжению \(format(result.tensionSafetyRatio))",
            requirement: "Больше 1.5",
            recommendation: ""
        )
    }

    func anchorCheck() -> SystemCheckItem {
        if result.anchorSafetyRatio < 1 {
            return SystemCheckItem(
                name: "Якорь",
                status: .failed,
                fact: "Запас удержания \(format(result.anchorSafetyRatio))",
                requirement: "Должен быть не меньше 1",
                recommendation: "Увеличьте массу якоря, выберите другой тип якоря или уточните грунт."
            )
        }

        if result.anchorSafetyRatio < 2 {
            return SystemCheckItem(
                name: "Якорь",
                status: .warning,
                fact: "Запас удержания \(format(result.anchorSafetyRatio))",
                requirement: "Желательно не меньше 2",
                recommendation: "Желательно увеличить запас удержания якоря."
            )
        }

        return SystemCheckItem(
            name: "Якорь",
            status: .ok,
            fact: "Запас удержания \(format(result.anchorSafetyRatio))",
            requirement: "Больше 2",
            recommendation: ""
        )
    }

    func offsetCheck() -> SystemCheckItem {
        if result.maxGeometricOffsetM <= 0 {
            return SystemCheckItem(
                name: "Снос",
                status: .warning,
                fact: "Геометрический предел сноса не определён",
                requirement: "Нужна линия длиннее глубины",
                recommendation: "Проверьте длину линии и глубину."
            )
        }

        if result.estimatedCurrentOffsetM > result.maxGeometricOffsetM * 0.8 {
            return SystemCheckItem(
                name: "Снос",
                status: .warning,
                fact: "Снос \(format(result.estimatedCurrentOffsetM)) м из \(format(result.maxGeometricOffsetM)) м",
                requirement: "Желательно меньше 80% геометрического предела",
                recommendation: "Увеличьте длину линии или уменьшите сопротивление элементов."
            )
        }

        return SystemCheckItem(
            name: "Снос",
            status: .ok,
            fact: "Снос \(format(result.estimatedCurrentOffsetM)) м",
            requirement: "Меньше 80% от \(format(result.maxGeometricOffsetM)) м",
            recommendation: ""
        )
    }

    func weakLinkCheck() -> SystemCheckItem {
        if result.systemMinimumBreakingLoadKn <= 0 {
            return SystemCheckItem(
                name: "Слабое звено",
                status: .failed,
                fact: "Слабое звено не определено",
                requirement: "Нужна MBL линии и соединителей",
                recommendation: "Задайте разрывные нагрузки всех элементов."
            )
        }

        return SystemCheckItem(
            name: "Слабое звено",
            status: .ok,
            fact: result.verdict.weakestElement,
            requirement: "Минимальная MBL системы \(format(result.systemMinimumBreakingLoadKn)) кН",
            recommendation: ""
        )
    }

    func format(_ value: Double) -> String {
        if value.isNaN || value.isInfinite {
            return "—"
        }

        if abs(value) >= 100 {
            return String(format: "%.0f", value)
        }

        return String(format: "%.2f", value)
    }
}

#Preview {
    let verdict = SystemVerdict(
        title: "✅ Система предварительно подходит",
        mainRisk: "Критических рисков не выявлено.",
        weakestElement: "Соединительные элементы",
        recommendation: "Можно переходить к уточнению исходных данных."
    )

    let result = CalculationResult(
        buoyVolumeM3: 0.5,
        grossBuoyancyKg: 512.5,
        buoyProjectedAreaM2: 0.8,
        mooringLineProjectedAreaM2: 1.0,
        connectorProjectedAreaM2: 0.02,
        payloadProjectedAreaM2: 0.05,
        buoyCurrentForceN: 80,
        mooringLineCurrentForceN: 150,
        connectorCurrentForceN: 5,
        payloadCurrentForceN: 10,
        totalCurrentForceN: 245,
        totalCurrentForceKn: 0.245,
        waveOrbitalVelocityMS: 0.52,
        buoyWaveForceN: 110,
        totalHorizontalForceN: 355,
        totalHorizontalForceKn: 0.355,
        payloadWeightInWaterKg: 40,
        mooringLineWeightInWaterKg: 25,
        connectorWeightInWaterKg: 2,
        totalVerticalLoadKg: 147,
        buoyancyReserveKg: 365.5,
        mooringLineLengthM: 55,
        mooringLineMinimumBreakingLoadKn: 70,
        connectorMinimumBreakingLoadKn: 55,
        systemMinimumBreakingLoadKn: 55,
        systemWorkingLoadKn: 11,
        estimatedLineTensionKn: 1.5,
        tensionSafetyRatio: 7.33,
        anchorWeightInWaterKg: 170,
        anchorEffectiveHoldingCoefficient: 1.0,
        anchorHoldingCapacityKn: 1.67,
        requiredHoldingKn: 0.355,
        anchorSafetyRatio: 4.7,
        maxGeometricOffsetM: 22.9,
        estimatedCurrentOffsetM: 5.0,
        mooringAngleDeg: 24.6,
        forceAngleDeg: 5.6,
        status: .ok,
        messages: [],
        verdict: verdict
    )

    SystemChecksView(
        result: result,
        depthM: 50,
        lineLengthM: 55
    )
    .padding()
}
