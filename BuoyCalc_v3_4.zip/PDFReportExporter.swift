import SwiftUI
import UIKit

// MARK: - Экспорт PDF-отчёта

struct PDFReportExporter {

    static func makePDFData(
        projectName: String,
        project: BuoyProject,
        result: CalculationResult,
        reportText: String,
        mooringLine: MooringLine,
        connectors: ConnectorSet,
        environment: Environment,
        buoy: Buoy,
        payload: Payload,
        anchor: Anchor,
        assemblyItems: [MooringAssemblyItemDraft],
        buoyTitle: String,
        anchorTitle: String,
        depthM: Double,
        lineLengthM: Double,
        estimatedOffsetM: Double,
        maxOffsetM: Double,
        currentSpeedMS: Double
    ) -> Data {

        let pageRect = CGRect(x: 0, y: 0, width: 595, height: 842) // A4 portrait, points
        let margin: CGFloat = 40
        let contentWidth = pageRect.width - margin * 2

        let renderer = UIGraphicsPDFRenderer(bounds: pageRect)

        let diagramImage = makeDiagramImage(
            depthM: depthM,
            lineLengthM: lineLengthM,
            estimatedOffsetM: estimatedOffsetM,
            maxOffsetM: maxOffsetM,
            currentSpeedMS: currentSpeedMS
        )

        let dateText = formattedDate(Date())

        let data = renderer.pdfData { context in

            // MARK: Page 1 - Title

            context.beginPage()
            drawTitlePage(
                pageRect: pageRect,
                margin: margin,
                projectName: projectName,
                dateText: dateText,
                result: result
            )

            drawFooter(
                pageRect: pageRect,
                pageNumber: 1,
                title: "BuoyCalc"
            )

            // MARK: Page 2 - Summary + Visualization

            context.beginPage()

            var y: CGFloat = margin

            y = drawHeader(
                "Сводка расчёта",
                pageRect: pageRect,
                margin: margin,
                y: y
            )

            y += 8

            y = drawVerdictBlock(
                result: result,
                x: margin,
                y: y,
                width: contentWidth
            )

            y += 18

            y = drawKeyMetricsTable(
                result: result,
                x: margin,
                y: y,
                width: contentWidth
            )

            y += 16

            y = drawSystemChecksTable(
                result: result,
                depthM: depthM,
                lineLengthM: lineLengthM,
                x: margin,
                y: y,
                width: contentWidth
            )

            y += 18

            drawSectionTitle(
                "Визуализация постановки",
                x: margin,
                y: y,
                width: contentWidth
            )
            y += 22

            let imageHeight: CGFloat = 205
            diagramImage.draw(in: CGRect(x: margin, y: y, width: contentWidth, height: imageHeight))
            y += imageHeight + 8

            drawText(
                "Схема показывает упрощённый вид системы сбоку. Масштаб адаптирован под страницу и не является строгим чертежом.",
                font: .systemFont(ofSize: 9),
                color: .darkGray,
                rect: CGRect(x: margin, y: y, width: contentWidth, height: 28)
            )

            drawFooter(
                pageRect: pageRect,
                pageNumber: 2,
                title: "Сводка и визуализация"
            )

            // MARK: Page 3 - Assembly sequence

            context.beginPage()

            var sequenceY: CGFloat = margin

            sequenceY = drawHeader(
                "Цепочка постановки",
                pageRect: pageRect,
                margin: margin,
                y: sequenceY
            )

            sequenceY += 8

            sequenceY = drawAssemblySequencePage(
                buoyTitle: buoyTitle,
                items: assemblyItems,
                anchorTitle: anchorTitle,
                x: margin,
                y: sequenceY,
                width: contentWidth,
                pageRect: pageRect
            )

            drawText(
                "Цепочка показывает логический порядок элементов сверху вниз. Масштаб и геометрия отображаются отдельно на 2D-схеме постановки.",
                font: .systemFont(ofSize: 9),
                color: .darkGray,
                rect: CGRect(x: margin, y: pageRect.height - 62, width: contentWidth, height: 24)
            )

            drawFooter(
                pageRect: pageRect,
                pageNumber: 3,
                title: "Цепочка постановки"
            )

            // MARK: Page 4+ - Detailed tables

            var pageNumber = 4

            context.beginPage()
            var tableY: CGFloat = margin

            tableY = drawHeader(
                "Расчётные таблицы",
                pageRect: pageRect,
                margin: margin,
                y: tableY
            )

            func ensureSpace(_ neededHeight: CGFloat, title: String = "Расчётные таблицы") {
                if tableY + neededHeight > pageRect.height - margin - 24 {
                    drawFooter(
                        pageRect: pageRect,
                        pageNumber: pageNumber,
                        title: "Расчётные таблицы"
                    )
                    pageNumber += 1
                    context.beginPage()
                    tableY = margin
                    tableY = drawHeader(
                        title,
                        pageRect: pageRect,
                        margin: margin,
                        y: tableY
                    )
                }
            }

            let checkRows = systemCheckRows(
                result: result,
                depthM: depthM,
                lineLengthM: lineLengthM
            )

            ensureSpace(detailedTableHeight(rowCount: checkRows.count) + 32)
            drawSectionTitle("Проверки системы", x: margin, y: tableY, width: contentWidth)
            tableY += 22
            tableY = drawDetailedTable(
                headers: ["Проверка", "Статус", "Фактическое значение", "Требование / ориентир"],
                rows: checkRows,
                x: margin,
                y: tableY,
                width: contentWidth,
                columnFractions: [0.28, 0.16, 0.28, 0.28]
            )
            tableY += 18

            let conditionsRows: [(String, String)] = [
                ("Название проекта", project.name),
                ("Глубина", "\(format(environment.depthM)) м"),
                ("Плотность воды", "\(format(environment.waterDensityKgM3)) кг/м³"),
                ("Скорость течения", "\(format(environment.currentSpeedMS)) м/с"),
                ("Высота волны", "\(format(environment.waveHeightM)) м"),
                ("Период волны", "\(format(environment.wavePeriodS)) с"),
                ("Тип грунта", environment.seabed.name),
                ("Множитель грунта", format(environment.seabed.holdingMultiplier))
            ]

            ensureSpace(simpleTableHeight(rowCount: conditionsRows.count) + 32)
            drawSectionTitle("Условия постановки", x: margin, y: tableY, width: contentWidth)
            tableY += 22
            tableY = drawSimpleTable(rows: conditionsRows, x: margin, y: tableY, width: contentWidth)
            tableY += 18

            let buoyRows: [(String, String)] = [
                ("Форма", buoy.shape.rawValue),
                ("Диаметр / ширина", "\(format(buoy.diameterM)) м"),
                ("Высота", "\(format(buoy.heightM)) м"),
                ("Объём", "\(format(result.buoyVolumeM3)) м³"),
                ("Масса", "\(format(buoy.weightKg)) кг"),
                ("Полная плавучесть", "\(format(result.grossBuoyancyKg)) кг"),
                ("Площадь сопротивления", "\(format(result.buoyProjectedAreaM2)) м²"),
                ("Сила течения на буй", "\(format(result.buoyCurrentForceN)) Н"),
                ("Волновая сила на буй", "\(format(result.buoyWaveForceN)) Н")
            ]

            ensureSpace(simpleTableHeight(rowCount: buoyRows.count) + 32)
            drawSectionTitle("Буй", x: margin, y: tableY, width: contentWidth)
            tableY += 22
            tableY = drawSimpleTable(rows: buoyRows, x: margin, y: tableY, width: contentWidth)
            tableY += 18

            let mooringRows = mooringLineRows(mooringLine)
            ensureSpace(detailedTableHeight(rowCount: mooringRows.count) + 32)
            drawSectionTitle("Швартовная линия", x: margin, y: tableY, width: contentWidth)
            tableY += 22
            tableY = drawDetailedTable(
                headers: ["#", "Материал", "Диам.", "Длина", "Вес", "MBL"],
                rows: mooringRows,
                x: margin,
                y: tableY,
                width: contentWidth,
                columnFractions: [0.07, 0.35, 0.13, 0.13, 0.15, 0.17]
            )
            tableY += 12

            let mooringSummaryRows: [(String, String)] = [
                ("Суммарная длина линии", "\(format(result.mooringLineLengthM)) м"),
                ("Вес линии в воде", "\(format(result.mooringLineWeightInWaterKg)) кг"),
                ("Площадь сопротивления линии", "\(format(result.mooringLineProjectedAreaM2)) м²"),
                ("Сила течения на линию", "\(format(result.mooringLineCurrentForceN)) Н"),
                ("Минимальная MBL линии", "\(format(result.mooringLineMinimumBreakingLoadKn)) кН")
            ]

            ensureSpace(simpleTableHeight(rowCount: mooringSummaryRows.count) + 16)
            tableY = drawSimpleTable(rows: mooringSummaryRows, x: margin, y: tableY, width: contentWidth)
            tableY += 18

            let connectorRows = connectorRows(connectors, environment: environment)
            ensureSpace(detailedTableHeight(rowCount: connectorRows.count) + 32)
            drawSectionTitle("Соединительные элементы", x: margin, y: tableY, width: contentWidth)
            tableY += 22
            tableY = drawDetailedTable(
                headers: ["#", "Тип", "Кол.", "Вес в воде", "Площадь", "MBL"],
                rows: connectorRows,
                x: margin,
                y: tableY,
                width: contentWidth,
                columnFractions: [0.07, 0.34, 0.10, 0.18, 0.15, 0.16]
            )
            tableY += 12

            let connectorSummaryRows: [(String, String)] = [
                ("Вес соединителей в воде", "\(format(result.connectorWeightInWaterKg)) кг"),
                ("Площадь сопротивления соединителей", "\(format(result.connectorProjectedAreaM2)) м²"),
                ("Сила течения на соединители", "\(format(result.connectorCurrentForceN)) Н"),
                ("Минимальная MBL соединителей", "\(format(result.connectorMinimumBreakingLoadKn)) кН")
            ]

            ensureSpace(simpleTableHeight(rowCount: connectorSummaryRows.count) + 16)
            tableY = drawSimpleTable(rows: connectorSummaryRows, x: margin, y: tableY, width: contentWidth)
            tableY += 18

            let payloadRows: [(String, String)] = [
                ("Название", payload.name),
                ("Масса в воздухе", "\(format(payload.weightAirKg)) кг"),
                ("Объём", "\(format(payload.volumeM3)) м³"),
                ("Вес в воде", "\(format(result.payloadWeightInWaterKg)) кг"),
                ("Площадь сопротивления", "\(format(result.payloadProjectedAreaM2)) м²"),
                ("Сила течения на прибор", "\(format(result.payloadCurrentForceN)) Н")
            ]

            ensureSpace(simpleTableHeight(rowCount: payloadRows.count) + 32)
            drawSectionTitle("Прибор / полезная нагрузка", x: margin, y: tableY, width: contentWidth)
            tableY += 22
            tableY = drawSimpleTable(rows: payloadRows, x: margin, y: tableY, width: contentWidth)
            tableY += 18

            let anchorRows: [(String, String)] = [
                ("Тип", anchor.type),
                ("Материал", anchor.material),
                ("Масса в воздухе", "\(format(anchor.weightAirKg)) кг"),
                ("Объём", "\(format(anchor.volumeM3)) м³"),
                ("Масса в воде", "\(format(result.anchorWeightInWaterKg)) кг"),
                ("Эффективный коэффициент удержания", format(result.anchorEffectiveHoldingCoefficient)),
                ("Удерживающая способность", "\(format(result.anchorHoldingCapacityKn)) кН"),
                ("Требуемое удержание", "\(format(result.requiredHoldingKn)) кН"),
                ("Запас удержания", format(result.anchorSafetyRatio))
            ]

            ensureSpace(simpleTableHeight(rowCount: anchorRows.count) + 32)
            drawSectionTitle("Якорь", x: margin, y: tableY, width: contentWidth)
            tableY += 22
            tableY = drawSimpleTable(rows: anchorRows, x: margin, y: tableY, width: contentWidth)
            tableY += 18

            let resultRows: [(String, String)] = [
                ("Суммарная сила течения", "\(format(result.totalCurrentForceN)) Н"),
                ("Суммарная горизонтальная сила", "\(format(result.totalHorizontalForceN)) Н"),
                ("Общая вертикальная нагрузка", "\(format(result.totalVerticalLoadKg)) кг"),
                ("Запас плавучести", "\(format(result.buoyancyReserveKg)) кг"),
                ("Минимальная MBL системы", "\(format(result.systemMinimumBreakingLoadKn)) кН"),
                ("Рабочая нагрузка системы", "\(format(result.systemWorkingLoadKn)) кН"),
                ("Расчётное натяжение системы", "\(format(result.estimatedLineTensionKn)) кН"),
                ("Запас по натяжению", format(result.tensionSafetyRatio)),
                ("Максимальный геометрический снос", "\(format(result.maxGeometricOffsetM)) м"),
                ("Расчётный снос", "\(format(result.estimatedCurrentOffsetM)) м"),
                ("Геометрический угол линии", "\(format(result.mooringAngleDeg))°"),
                ("Угол от соотношения сил", "\(format(result.forceAngleDeg))°")
            ]

            ensureSpace(simpleTableHeight(rowCount: resultRows.count) + 32)
            drawSectionTitle("Расчётные итоги", x: margin, y: tableY, width: contentWidth)
            tableY += 22
            tableY = drawSimpleTable(rows: resultRows, x: margin, y: tableY, width: contentWidth)

            drawFooter(
                pageRect: pageRect,
                pageNumber: pageNumber,
                title: "Расчётные таблицы"
            )
            pageNumber += 1

            // MARK: Pages after tables - Full text report

            let reportLines = reportText.components(separatedBy: "\n")
            var lineIndex = 0

            while lineIndex < reportLines.count {
                context.beginPage()

                var reportY: CGFloat = margin

                reportY = drawHeader(
                    lineIndex == 0 ? "Полный текстовый отчёт" : "Полный текстовый отчёт - продолжение",
                    pageRect: pageRect,
                    margin: margin,
                    y: reportY
                )

                reportY += 8

                lineIndex = drawReportLines(
                    lines: reportLines,
                    startIndex: lineIndex,
                    x: margin,
                    y: reportY,
                    width: contentWidth,
                    pageRect: pageRect,
                    bottomMargin: margin + 22
                )

                drawFooter(
                    pageRect: pageRect,
                    pageNumber: pageNumber,
                    title: "Полный отчёт"
                )

                pageNumber += 1
            }
        }

        return data
    }

    // MARK: - Title page

    private static func drawTitlePage(
        pageRect: CGRect,
        margin: CGFloat,
        projectName: String,
        dateText: String,
        result: CalculationResult
    ) {

        let contentWidth = pageRect.width - margin * 2

        drawText(
            "BuoyCalc",
            font: .boldSystemFont(ofSize: 34),
            color: .black,
            rect: CGRect(x: margin, y: 90, width: contentWidth, height: 44)
        )

        drawText(
            "Предварительный инженерный отчёт",
            font: .systemFont(ofSize: 18),
            color: .darkGray,
            rect: CGRect(x: margin, y: 138, width: contentWidth, height: 26)
        )

        drawLine(
            from: CGPoint(x: margin, y: 180),
            to: CGPoint(x: pageRect.width - margin, y: 180),
            color: .black,
            width: 1.2
        )

        drawText(
            "Проект",
            font: .boldSystemFont(ofSize: 13),
            color: .darkGray,
            rect: CGRect(x: margin, y: 210, width: contentWidth, height: 18)
        )

        drawText(
            projectName.isEmpty ? "Без названия" : projectName,
            font: .boldSystemFont(ofSize: 22),
            color: .black,
            rect: CGRect(x: margin, y: 232, width: contentWidth, height: 40)
        )

        drawText(
            "Дата формирования: \(dateText)",
            font: .systemFont(ofSize: 11),
            color: .darkGray,
            rect: CGRect(x: margin, y: 280, width: contentWidth, height: 18)
        )

        let verdictRect = CGRect(x: margin, y: 330, width: contentWidth, height: 140)
        drawRoundedRect(
            verdictRect,
            fillColor: statusColor(result.status).withAlphaComponent(0.14),
            strokeColor: statusColor(result.status).withAlphaComponent(0.7)
        )

        drawText(
            "Итоговый вердикт",
            font: .boldSystemFont(ofSize: 13),
            color: .darkGray,
            rect: CGRect(x: verdictRect.minX + 16, y: verdictRect.minY + 16, width: verdictRect.width - 32, height: 18)
        )

        drawText(
            result.verdict.title,
            font: .boldSystemFont(ofSize: 20),
            color: .black,
            rect: CGRect(x: verdictRect.minX + 16, y: verdictRect.minY + 42, width: verdictRect.width - 32, height: 28)
        )

        drawText(
            "Главный риск: \(result.verdict.mainRisk)",
            font: .systemFont(ofSize: 11),
            color: .black,
            rect: CGRect(x: verdictRect.minX + 16, y: verdictRect.minY + 76, width: verdictRect.width - 32, height: 24)
        )

        drawText(
            "Слабое звено: \(result.verdict.weakestElement)",
            font: .systemFont(ofSize: 11),
            color: .black,
            rect: CGRect(x: verdictRect.minX + 16, y: verdictRect.minY + 104, width: verdictRect.width - 32, height: 20)
        )

        let notice = """
        Важно: отчёт является предварительным расчётом. Для реального проектирования необходимы паспортные данные элементов, уточнение грунта, проверочная инженерная методика и оценка условий района постановки.
        """

        drawText(
            notice,
            font: .systemFont(ofSize: 10),
            color: .darkGray,
            rect: CGRect(x: margin, y: 560, width: contentWidth, height: 70)
        )
    }

    // MARK: - Summary page blocks

    private static func drawVerdictBlock(
        result: CalculationResult,
        x: CGFloat,
        y: CGFloat,
        width: CGFloat
    ) -> CGFloat {

        let height: CGFloat = 118
        let rect = CGRect(x: x, y: y, width: width, height: height)

        drawRoundedRect(
            rect,
            fillColor: statusColor(result.status).withAlphaComponent(0.13),
            strokeColor: statusColor(result.status).withAlphaComponent(0.7)
        )

        drawText(
            result.verdict.title,
            font: .boldSystemFont(ofSize: 16),
            color: .black,
            rect: CGRect(x: x + 14, y: y + 12, width: width - 28, height: 22)
        )

        drawText(
            "Главный риск: \(result.verdict.mainRisk)",
            font: .systemFont(ofSize: 10),
            color: .black,
            rect: CGRect(x: x + 14, y: y + 42, width: width - 28, height: 24)
        )

        drawText(
            "Рекомендация: \(result.verdict.recommendation)",
            font: .systemFont(ofSize: 10),
            color: .black,
            rect: CGRect(x: x + 14, y: y + 72, width: width - 28, height: 34)
        )

        return y + height
    }

    private static func drawKeyMetricsTable(
        result: CalculationResult,
        x: CGFloat,
        y: CGFloat,
        width: CGFloat
    ) -> CGFloat {

        drawSectionTitle("Ключевые показатели", x: x, y: y, width: width)

        let rows: [(String, String)] = [
            ("Запас плавучести", "\(format(result.buoyancyReserveKg)) кг"),
            ("Запас удержания якоря", format(result.anchorSafetyRatio)),
            ("Запас по натяжению", format(result.tensionSafetyRatio)),
            ("Рабочая нагрузка системы", "\(format(result.systemWorkingLoadKn)) кН"),
            ("Расчётное натяжение", "\(format(result.estimatedLineTensionKn)) кН"),
            ("Расчётный снос", "\(format(result.estimatedCurrentOffsetM)) м")
        ]

        return drawSimpleTable(
            rows: rows,
            x: x,
            y: y + 24,
            width: width
        )
    }


    // MARK: - System checks

    private static func drawSystemChecksTable(
        result: CalculationResult,
        depthM: Double,
        lineLengthM: Double,
        x: CGFloat,
        y: CGFloat,
        width: CGFloat
    ) -> CGFloat {

        drawSectionTitle("Проверки системы", x: x, y: y, width: width)

        let rows = systemCheckRows(
            result: result,
            depthM: depthM,
            lineLengthM: lineLengthM
        )

        return drawDetailedTable(
            headers: ["Проверка", "Статус", "Факт", "Ориентир"],
            rows: rows,
            x: x,
            y: y + 22,
            width: width,
            columnFractions: [0.30, 0.17, 0.25, 0.28]
        )
    }

    private static func systemCheckRows(
        result: CalculationResult,
        depthM: Double,
        lineLengthM: Double
    ) -> [[String]] {

        let buoyancyStatus: String
        let buoyancyRequirement: String

        if result.buoyancyReserveKg <= 0 {
            buoyancyStatus = "FAILED"
            buoyancyRequirement = "> 0 кг"
        } else if result.buoyancyReserveKg < result.totalVerticalLoadKg * 0.2 {
            buoyancyStatus = "WARNING"
            buoyancyRequirement = "желательно > 20% нагрузки"
        } else {
            buoyancyStatus = "OK"
            buoyancyRequirement = "> 20% нагрузки"
        }

        let lineLengthStatus = lineLengthM >= depthM ? "OK" : "FAILED"

        let tensionStatus: String
        if result.systemWorkingLoadKn <= 0 {
            tensionStatus = "FAILED"
        } else if result.estimatedLineTensionKn > result.systemWorkingLoadKn {
            tensionStatus = "FAILED"
        } else if result.tensionSafetyRatio < 1.5 {
            tensionStatus = "WARNING"
        } else {
            tensionStatus = "OK"
        }

        let anchorStatus: String
        if result.anchorSafetyRatio < 1 {
            anchorStatus = "FAILED"
        } else if result.anchorSafetyRatio < 2 {
            anchorStatus = "WARNING"
        } else {
            anchorStatus = "OK"
        }

        let offsetStatus: String
        if result.maxGeometricOffsetM <= 0 {
            offsetStatus = "WARNING"
        } else if result.estimatedCurrentOffsetM > result.maxGeometricOffsetM * 0.8 {
            offsetStatus = "WARNING"
        } else {
            offsetStatus = "OK"
        }

        let weakLinkStatus = result.systemMinimumBreakingLoadKn > 0 ? "OK" : "FAILED"

        return [
            [
                "Плавучесть",
                buoyancyStatus,
                "\(format(result.buoyancyReserveKg)) кг",
                buoyancyRequirement
            ],
            [
                "Длина линии",
                lineLengthStatus,
                "\(format(lineLengthM)) м",
                ">= глубины \(format(depthM)) м"
            ],
            [
                "Натяжение",
                tensionStatus,
                "\(format(result.estimatedLineTensionKn)) кН",
                "<= WLL \(format(result.systemWorkingLoadKn)) кН"
            ],
            [
                "Якорь",
                anchorStatus,
                "запас \(format(result.anchorSafetyRatio))",
                ">= 2 желательно"
            ],
            [
                "Снос",
                offsetStatus,
                "\(format(result.estimatedCurrentOffsetM)) м",
                "< 80% от \(format(result.maxGeometricOffsetM)) м"
            ],
            [
                "Слабое звено",
                weakLinkStatus,
                result.verdict.weakestElement,
                "MBL \(format(result.systemMinimumBreakingLoadKn)) кН"
            ]
        ]
    }

    // MARK: - Table rows

    private static func mooringLineRows(_ line: MooringLine) -> [[String]] {
        if line.segments.isEmpty {
            return [["-", "Не задано", "-", "-", "-", "-"]]
        }

        return line.segments.enumerated().map { index, segment in
            [
                "\(index + 1)",
                segment.material,
                "\(format(segment.diameterMm)) мм",
                "\(format(segment.lengthM)) м",
                "\(format(segment.weightInWaterKg())) кг",
                "\(format(segment.breakingLoadKn)) кН"
            ]
        }
    }

    private static func connectorRows(
        _ connectors: ConnectorSet,
        environment: Environment
    ) -> [[String]] {
        if connectors.elements.isEmpty {
            return [["-", "Не задано", "-", "-", "-", "-"]]
        }

        return connectors.elements.enumerated().map { index, item in
            [
                "\(index + 1)",
                item.type,
                "\(item.count)",
                "\(format(item.totalWeightInWaterKg(waterDensityKgM3: environment.waterDensityKgM3))) кг",
                "\(format(item.totalProjectedAreaM2())) м²",
                "\(format(item.breakingLoadKn)) кН"
            ]
        }
    }

    private static func simpleTableHeight(rowCount: Int) -> CGFloat {
        return CGFloat(rowCount) * 24
    }

    private static func detailedTableHeight(rowCount: Int) -> CGFloat {
        return 26 + CGFloat(rowCount) * 26
    }


    // MARK: - Assembly sequence page

    private static func drawAssemblySequencePage(
        buoyTitle: String,
        items: [MooringAssemblyItemDraft],
        anchorTitle: String,
        x: CGFloat,
        y: CGFloat,
        width: CGFloat,
        pageRect: CGRect
    ) -> CGFloat {

        var currentY = y

        currentY = drawAssemblyNode(
            title: buoyTitle.isEmpty ? "Буй" : buoyTitle,
            subtitle: "Верхняя плавучая точка",
            kindTitle: "Буй",
            fillColor: UIColor.systemBlue.withAlphaComponent(0.10),
            strokeColor: UIColor.systemBlue.withAlphaComponent(0.55),
            x: x,
            y: currentY,
            width: width
        )

        let enabledItems = items.filter { $0.isEnabled }

        for (index, item) in enabledItems.enumerated() {
            if currentY + 72 > pageRect.height - 96 {
                drawText(
                    "… часть последовательности не помещается на этой странице и приведена в полном текстовом отчёте.",
                    font: .systemFont(ofSize: 9),
                    color: .darkGray,
                    rect: CGRect(x: x, y: currentY + 8, width: width, height: 28)
                )
                return currentY + 40
            }

            currentY = drawAssemblyArrow(x: x, y: currentY, width: width)

            currentY = drawAssemblyNode(
                title: item.title.isEmpty ? item.kind.shortTitle : item.title,
                subtitle: assemblySubtitle(item),
                kindTitle: "\(index + 1). \(item.kind.shortTitle)",
                fillColor: assemblyFillColor(item.kind),
                strokeColor: assemblyStrokeColor(item.kind),
                x: x,
                y: currentY,
                width: width
            )
        }

        currentY = drawAssemblyArrow(x: x, y: currentY, width: width)

        _ = drawAssemblyNode(
            title: anchorTitle.isEmpty ? "Якорь" : anchorTitle,
            subtitle: "Нижняя точка удержания",
            kindTitle: "Якорь",
            fillColor: UIColor.brown.withAlphaComponent(0.10),
            strokeColor: UIColor.brown.withAlphaComponent(0.55),
            x: x,
            y: currentY,
            width: width
        )

        return currentY
    }

    private static func drawAssemblyNode(
        title: String,
        subtitle: String,
        kindTitle: String,
        fillColor: UIColor,
        strokeColor: UIColor,
        x: CGFloat,
        y: CGFloat,
        width: CGFloat
    ) -> CGFloat {

        let height: CGFloat = 54
        let rect = CGRect(x: x, y: y, width: width, height: height)

        drawRoundedRect(
            rect,
            fillColor: fillColor,
            strokeColor: strokeColor
        )

        drawText(
            kindTitle,
            font: .boldSystemFont(ofSize: 9),
            color: .darkGray,
            rect: CGRect(x: x + 12, y: y + 9, width: 120, height: 14)
        )

        drawText(
            title,
            font: .boldSystemFont(ofSize: 11),
            color: .black,
            rect: CGRect(x: x + 138, y: y + 8, width: width - 150, height: 16)
        )

        drawText(
            subtitle,
            font: .systemFont(ofSize: 9),
            color: .darkGray,
            rect: CGRect(x: x + 138, y: y + 29, width: width - 150, height: 16)
        )

        return y + height
    }

    private static func drawAssemblyArrow(
        x: CGFloat,
        y: CGFloat,
        width: CGFloat
    ) -> CGFloat {
        let arrowY = y + 9
        let centerX = x + width / 2

        drawLine(
            from: CGPoint(x: centerX, y: arrowY),
            to: CGPoint(x: centerX, y: arrowY + 12),
            color: .gray,
            width: 0.8
        )

        drawLine(
            from: CGPoint(x: centerX, y: arrowY + 12),
            to: CGPoint(x: centerX - 4, y: arrowY + 7),
            color: .gray,
            width: 0.8
        )

        drawLine(
            from: CGPoint(x: centerX, y: arrowY + 12),
            to: CGPoint(x: centerX + 4, y: arrowY + 7),
            color: .gray,
            width: 0.8
        )

        return y + 24
    }

    private static func assemblySubtitle(_ item: MooringAssemblyItemDraft) -> String {
        switch item.kind {
        case .connector:
            return "Соединитель · \(item.countText) шт."
        case .line:
            return "Буйреп / линия · \(item.lengthText) м"
        case .payload:
            return "Прибор / нагрузка · \(item.weightAirText) кг"
        }
    }

    private static func assemblyFillColor(_ kind: MooringAssemblyItemKind) -> UIColor {
        switch kind {
        case .connector:
            return UIColor.systemOrange.withAlphaComponent(0.10)
        case .line:
            return UIColor.systemCyan.withAlphaComponent(0.10)
        case .payload:
            return UIColor.systemPurple.withAlphaComponent(0.10)
        }
    }

    private static func assemblyStrokeColor(_ kind: MooringAssemblyItemKind) -> UIColor {
        switch kind {
        case .connector:
            return UIColor.systemOrange.withAlphaComponent(0.55)
        case .line:
            return UIColor.systemCyan.withAlphaComponent(0.55)
        case .payload:
            return UIColor.systemPurple.withAlphaComponent(0.55)
        }
    }

    // MARK: - Report text pages

    private static func drawReportLines(
        lines: [String],
        startIndex: Int,
        x: CGFloat,
        y: CGFloat,
        width: CGFloat,
        pageRect: CGRect,
        bottomMargin: CGFloat
    ) -> Int {

        var index = startIndex
        var currentY = y

        let normalFont = UIFont.monospacedSystemFont(ofSize: 8.3, weight: .regular)
        let headerFont = UIFont.boldSystemFont(ofSize: 10)
        let lineHeight: CGFloat = 11.2

        while index < lines.count {
            if currentY + lineHeight > pageRect.height - bottomMargin {
                break
            }

            let line = lines[index]
            let isHeader = line.hasPrefix("#") || line.hasPrefix("##")
            let isDivider = line.trimmingCharacters(in: .whitespacesAndNewlines) == "---"

            if isDivider {
                drawLine(
                    from: CGPoint(x: x, y: currentY + 4),
                    to: CGPoint(x: x + width, y: currentY + 4),
                    color: .lightGray,
                    width: 0.5
                )
                currentY += 8
            } else {
                drawText(
                    line,
                    font: isHeader ? headerFont : normalFont,
                    color: isHeader ? .black : .darkGray,
                    rect: CGRect(x: x, y: currentY, width: width, height: lineHeight + 2)
                )
                currentY += isHeader ? 14 : lineHeight
            }

            index += 1
        }

        return index
    }

    // MARK: - Drawing helpers

    private static func drawHeader(
        _ title: String,
        pageRect: CGRect,
        margin: CGFloat,
        y: CGFloat
    ) -> CGFloat {

        drawText(
            title,
            font: .boldSystemFont(ofSize: 18),
            color: .black,
            rect: CGRect(x: margin, y: y, width: pageRect.width - margin * 2, height: 24)
        )

        drawLine(
            from: CGPoint(x: margin, y: y + 32),
            to: CGPoint(x: pageRect.width - margin, y: y + 32),
            color: .black,
            width: 0.8
        )

        return y + 42
    }

    private static func drawFooter(
        pageRect: CGRect,
        pageNumber: Int,
        title: String
    ) {
        let text = "\(title) · страница \(pageNumber)"
        drawText(
            text,
            font: .systemFont(ofSize: 8),
            color: .gray,
            rect: CGRect(x: 40, y: pageRect.height - 26, width: pageRect.width - 80, height: 12)
        )
    }

    private static func drawSectionTitle(
        _ title: String,
        x: CGFloat,
        y: CGFloat,
        width: CGFloat
    ) {
        drawText(
            title,
            font: .boldSystemFont(ofSize: 13),
            color: .black,
            rect: CGRect(x: x, y: y, width: width, height: 18)
        )
    }

    private static func drawSimpleTable(
        rows: [(String, String)],
        x: CGFloat,
        y: CGFloat,
        width: CGFloat
    ) -> CGFloat {

        let rowHeight: CGFloat = 24
        let leftWidth = width * 0.58

        var currentY = y

        for (index, row) in rows.enumerated() {
            let fillColor: UIColor = index.isMultiple(of: 2)
                ? UIColor(white: 0.96, alpha: 1)
                : UIColor.white

            fillColor.setFill()
            UIBezierPath(rect: CGRect(x: x, y: currentY, width: width, height: rowHeight)).fill()

            UIColor(white: 0.84, alpha: 1).setStroke()
            UIBezierPath(rect: CGRect(x: x, y: currentY, width: width, height: rowHeight)).stroke()

            drawText(
                row.0,
                font: .systemFont(ofSize: 9.5),
                color: .black,
                rect: CGRect(x: x + 8, y: currentY + 6, width: leftWidth - 12, height: rowHeight - 8)
            )

            drawText(
                row.1,
                font: .boldSystemFont(ofSize: 9.5),
                color: .black,
                rect: CGRect(x: x + leftWidth + 8, y: currentY + 6, width: width - leftWidth - 16, height: rowHeight - 8)
            )

            currentY += rowHeight
        }

        return currentY
    }

    private static func drawDetailedTable(
        headers: [String],
        rows: [[String]],
        x: CGFloat,
        y: CGFloat,
        width: CGFloat,
        columnFractions: [CGFloat]
    ) -> CGFloat {

        let headerHeight: CGFloat = 26
        let rowHeight: CGFloat = 26
        var currentY = y

        drawDetailedRow(
            values: headers,
            x: x,
            y: currentY,
            width: width,
            height: headerHeight,
            columnFractions: columnFractions,
            fillColor: UIColor(white: 0.88, alpha: 1),
            font: .boldSystemFont(ofSize: 8.5),
            textColor: .black
        )

        currentY += headerHeight

        for (index, row) in rows.enumerated() {
            let fillColor: UIColor = index.isMultiple(of: 2)
                ? UIColor(white: 0.97, alpha: 1)
                : UIColor.white

            drawDetailedRow(
                values: row,
                x: x,
                y: currentY,
                width: width,
                height: rowHeight,
                columnFractions: columnFractions,
                fillColor: fillColor,
                font: .systemFont(ofSize: 7.7),
                textColor: .black
            )

            currentY += rowHeight
        }

        return currentY
    }

    private static func drawDetailedRow(
        values: [String],
        x: CGFloat,
        y: CGFloat,
        width: CGFloat,
        height: CGFloat,
        columnFractions: [CGFloat],
        fillColor: UIColor,
        font: UIFont,
        textColor: UIColor
    ) {

        var currentX = x

        for index in 0..<values.count {
            let fraction = index < columnFractions.count ? columnFractions[index] : 1.0 / CGFloat(values.count)
            let columnWidth = width * fraction

            fillColor.setFill()
            UIBezierPath(rect: CGRect(x: currentX, y: y, width: columnWidth, height: height)).fill()

            UIColor(white: 0.82, alpha: 1).setStroke()
            UIBezierPath(rect: CGRect(x: currentX, y: y, width: columnWidth, height: height)).stroke()

            drawText(
                values[index],
                font: font,
                color: textColor,
                rect: CGRect(x: currentX + 4, y: y + 6, width: columnWidth - 8, height: height - 8)
            )

            currentX += columnWidth
        }
    }

    private static func drawText(
        _ text: String,
        font: UIFont,
        color: UIColor,
        rect: CGRect
    ) {
        let paragraph = NSMutableParagraphStyle()
        paragraph.lineBreakMode = .byWordWrapping

        let attributes: [NSAttributedString.Key: Any] = [
            .font: font,
            .foregroundColor: color,
            .paragraphStyle: paragraph
        ]

        let attributedString = NSAttributedString(
            string: text,
            attributes: attributes
        )

        attributedString.draw(in: rect)
    }

    private static func drawLine(
        from: CGPoint,
        to: CGPoint,
        color: UIColor,
        width: CGFloat
    ) {
        let path = UIBezierPath()
        path.move(to: from)
        path.addLine(to: to)

        color.setStroke()
        path.lineWidth = width
        path.stroke()
    }

    private static func drawRoundedRect(
        _ rect: CGRect,
        fillColor: UIColor,
        strokeColor: UIColor
    ) {
        let path = UIBezierPath(roundedRect: rect, cornerRadius: 12)
        fillColor.setFill()
        path.fill()

        strokeColor.setStroke()
        path.lineWidth = 1
        path.stroke()
    }

    private static func statusColor(_ status: SystemStatus) -> UIColor {
        switch status {
        case .ok:
            return UIColor.systemGreen
        case .warning:
            return UIColor.systemOrange
        case .failed:
            return UIColor.systemRed
        }
    }

    // MARK: - Diagram

    static func makeDiagramImage(
        depthM: Double,
        lineLengthM: Double,
        estimatedOffsetM: Double,
        maxOffsetM: Double,
        currentSpeedMS: Double
    ) -> UIImage {
        let view = MooringSideView(
            depthM: depthM,
            lineLengthM: lineLengthM,
            estimatedOffsetM: estimatedOffsetM,
            maxOffsetM: maxOffsetM,
            currentSpeedMS: currentSpeedMS
        )
        .frame(width: 520, height: 280)
        .padding(8)
        .background(Color.white)

        let renderer = ImageRenderer(content: view)
        renderer.scale = 2

        return renderer.uiImage ?? UIImage()
    }

    // MARK: - Formatting

    private static func formattedDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "dd.MM.yyyy HH:mm"
        return formatter.string(from: date)
    }

    private static func format(_ value: Double) -> String {
        if value.isNaN || value.isInfinite {
            return "—"
        }

        if abs(value) >= 100 {
            return String(format: "%.0f", value)
        }

        return String(format: "%.2f", value)
    }
}
