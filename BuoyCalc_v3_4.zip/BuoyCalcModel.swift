import Foundation

// MARK: - Константы

enum CalculationConstants {
    static let gravityMS2 = 9.81
}

// MARK: - Статус системы

enum SystemStatus {
    case ok
    case warning
    case failed

    var title: String {
        switch self {
        case .ok:
            return "✅ Предварительно подходит"
        case .warning:
            return "⚠️ Требуется проверка"
        case .failed:
            return "❌ Не подходит"
        }
    }
}

// MARK: - Итоговый вердикт

struct SystemVerdict {
    var title: String
    var mainRisk: String
    var weakestElement: String
    var recommendation: String
}

// MARK: - Форма буя

enum BuoyShape: String, CaseIterable, Identifiable {
    case cylinder = "Цилиндр"
    case sphere = "Сфера"
    case custom = "Пользовательский объём"

    var id: String {
        rawValue
    }
}

// MARK: - Условия среды

struct Environment {
    var waterDensityKgM3: Double
    var depthM: Double
    var currentSpeedMS: Double

    var waveHeightM: Double
    var wavePeriodS: Double

    var seabed: SeabedPreset
}

// MARK: - Буй

struct Buoy {
    var shape: BuoyShape

    var diameterM: Double
    var heightM: Double
    var customVolumeM3: Double

    var weightKg: Double
    var dragCoefficient: Double

    func volumeM3() -> Double {
        let radius = diameterM / 2

        switch shape {
        case .cylinder:
            return Double.pi * radius * radius * heightM

        case .sphere:
            return 4.0 / 3.0 * Double.pi * radius * radius * radius

        case .custom:
            return customVolumeM3
        }
    }

    func projectedAreaM2() -> Double {
        let radius = diameterM / 2

        switch shape {
        case .cylinder:
            return diameterM * heightM

        case .sphere:
            return Double.pi * radius * radius

        case .custom:
            let areaFromDimensions = diameterM * heightM

            if areaFromDimensions > 0 {
                return areaFromDimensions
            }

            if customVolumeM3 > 0 {
                return pow(customVolumeM3, 2.0 / 3.0)
            }

            return 0
        }
    }
}

// MARK: - Участок швартовной линии

struct MooringSegment: Identifiable {
    var id = UUID()

    var name: String
    var material: String

    var diameterMm: Double
    var lengthM: Double

    var breakingLoadKn: Double
    var weightWaterKgM: Double
    var dragCoefficient: Double

    func weightInWaterKg() -> Double {
        return lengthM * weightWaterKgM
    }

    func projectedAreaM2() -> Double {
        let diameterM = diameterMm / 1000
        return diameterM * lengthM
    }
}

// MARK: - Составная швартовная линия

struct MooringLine {
    var segments: [MooringSegment]

    func totalLengthM() -> Double {
        return segments.reduce(0) { $0 + $1.lengthM }
    }

    func weightInWaterKg() -> Double {
        return segments.reduce(0) { $0 + $1.weightInWaterKg() }
    }

    func projectedAreaM2() -> Double {
        return segments.reduce(0) { $0 + $1.projectedAreaM2() }
    }

    func minimumBreakingLoadKn() -> Double {
        let validLoads = segments
            .map { $0.breakingLoadKn }
            .filter { $0 > 0 }

        return validLoads.min() ?? 0
    }

    func segmentSummary() -> String {
        if segments.isEmpty {
            return "Нет участков"
        }

        return segments.map { segment in
            "\(segment.material), \(format(segment.diameterMm)) мм, \(format(segment.lengthM)) м, MBL \(format(segment.breakingLoadKn)) кН"
        }.joined(separator: "\n")
    }

    private func format(_ value: Double) -> String {
        return String(format: "%.2f", value)
    }
}

// MARK: - Соединительный элемент

struct ConnectorElement: Identifiable {
    var id = UUID()

    var name: String
    var type: String

    var count: Int

    var weightAirKg: Double
    var volumeM3: Double

    var breakingLoadKn: Double
    var projectedAreaM2: Double
    var dragCoefficient: Double

    func totalWeightInWaterKg(waterDensityKgM3: Double) -> Double {
        let oneItemWeight: Double

        if volumeM3 <= 0 {
            oneItemWeight = weightAirKg
        } else {
            oneItemWeight = weightAirKg - waterDensityKgM3 * volumeM3
        }

        return max(oneItemWeight, 0) * Double(count)
    }

    func totalProjectedAreaM2() -> Double {
        return projectedAreaM2 * Double(count)
    }
}

// MARK: - Набор соединителей

struct ConnectorSet {
    var elements: [ConnectorElement]

    func totalWeightInWaterKg(waterDensityKgM3: Double) -> Double {
        return elements.reduce(0) {
            $0 + $1.totalWeightInWaterKg(waterDensityKgM3: waterDensityKgM3)
        }
    }

    func totalProjectedAreaM2() -> Double {
        return elements.reduce(0) {
            $0 + $1.totalProjectedAreaM2()
        }
    }

    func minimumBreakingLoadKn() -> Double {
        let validLoads = elements
            .filter { $0.count > 0 }
            .map { $0.breakingLoadKn }
            .filter { $0 > 0 }

        return validLoads.min() ?? 0
    }

    func summary() -> String {
        if elements.isEmpty {
            return "Соединители не заданы"
        }

        return elements.map { item in
            "\(item.type), \(item.count) шт., MBL \(format(item.breakingLoadKn)) кН"
        }.joined(separator: "\n")
    }

    private func format(_ value: Double) -> String {
        return String(format: "%.2f", value)
    }
}

// MARK: - Прибор / полезная нагрузка

struct Payload {
    var name: String

    var weightAirKg: Double
    var volumeM3: Double

    var projectedAreaM2: Double
    var dragCoefficient: Double

    func weightInWaterKg(waterDensityKgM3: Double) -> Double {
        if volumeM3 <= 0 {
            return weightAirKg
        }

        let buoyancyKg = volumeM3 * waterDensityKgM3
        return weightAirKg - buoyancyKg
    }
}

// MARK: - Якорь

struct Anchor {
    var name: String
    var type: String
    var material: String

    var weightAirKg: Double
    var volumeM3: Double

    var baseHoldingCoefficient: Double

    func effectiveHoldingCoefficient(seabed: SeabedPreset) -> Double {
        return baseHoldingCoefficient * seabed.holdingMultiplier
    }

    func weightInWaterKg(waterDensityKgM3: Double) -> Double {
        if volumeM3 <= 0 {
            return weightAirKg
        }

        let buoyancyKg = volumeM3 * waterDensityKgM3
        return max(weightAirKg - buoyancyKg, 0)
    }

    func holdingCapacityKn(
        waterDensityKgM3: Double,
        seabed: SeabedPreset
    ) -> Double {
        let holdingKg =
            weightInWaterKg(waterDensityKgM3: waterDensityKgM3) *
            effectiveHoldingCoefficient(seabed: seabed)

        return holdingKg * CalculationConstants.gravityMS2 / 1000
    }
}

// MARK: - Результат расчёта

struct CalculationResult {
    var buoyVolumeM3: Double
    var grossBuoyancyKg: Double

    var buoyProjectedAreaM2: Double
    var mooringLineProjectedAreaM2: Double
    var connectorProjectedAreaM2: Double
    var payloadProjectedAreaM2: Double

    var buoyCurrentForceN: Double
    var mooringLineCurrentForceN: Double
    var connectorCurrentForceN: Double
    var payloadCurrentForceN: Double
    var totalCurrentForceN: Double
    var totalCurrentForceKn: Double

    var waveOrbitalVelocityMS: Double
    var buoyWaveForceN: Double

    var totalHorizontalForceN: Double
    var totalHorizontalForceKn: Double

    var payloadWeightInWaterKg: Double
    var mooringLineWeightInWaterKg: Double
    var connectorWeightInWaterKg: Double
    var totalVerticalLoadKg: Double
    var buoyancyReserveKg: Double

    var mooringLineLengthM: Double
    var mooringLineMinimumBreakingLoadKn: Double
    var connectorMinimumBreakingLoadKn: Double
    var systemMinimumBreakingLoadKn: Double
    var systemWorkingLoadKn: Double

    var estimatedLineTensionKn: Double
    var tensionSafetyRatio: Double

    var anchorWeightInWaterKg: Double
    var anchorEffectiveHoldingCoefficient: Double
    var anchorHoldingCapacityKn: Double
    var requiredHoldingKn: Double
    var anchorSafetyRatio: Double

    var maxGeometricOffsetM: Double
    var estimatedCurrentOffsetM: Double
    var mooringAngleDeg: Double
    var forceAngleDeg: Double

    var status: SystemStatus
    var messages: [String]
    var verdict: SystemVerdict
}

// MARK: - Проект

struct BuoyProject {
    var name: String

    var environment: Environment
    var buoy: Buoy
    var mooringLine: MooringLine
    var connectors: ConnectorSet
    var payload: Payload
    var anchor: Anchor

    var safetyFactor: Double

    func calculate() -> CalculationResult {

        let buoyVolume = buoy.volumeM3()
        let grossBuoyancy = buoyVolume * environment.waterDensityKgM3

        let buoyProjectedArea = buoy.projectedAreaM2()
        let mooringLineProjectedArea = mooringLine.projectedAreaM2()
        let connectorProjectedArea = connectors.totalProjectedAreaM2()
        let payloadProjectedArea = payload.projectedAreaM2

        let buoyCurrentForce = hydrodynamicForceN(
            waterDensityKgM3: environment.waterDensityKgM3,
            dragCoefficient: buoy.dragCoefficient,
            projectedAreaM2: buoyProjectedArea,
            currentSpeedMS: environment.currentSpeedMS
        )

        let mooringLineCurrentForce = mooringLine.segments.reduce(0.0) { partialResult, segment in
            partialResult + hydrodynamicForceN(
                waterDensityKgM3: environment.waterDensityKgM3,
                dragCoefficient: segment.dragCoefficient,
                projectedAreaM2: segment.projectedAreaM2(),
                currentSpeedMS: environment.currentSpeedMS
            )
        }

        let connectorCurrentForce = connectors.elements.reduce(0.0) { partialResult, item in
            partialResult + hydrodynamicForceN(
                waterDensityKgM3: environment.waterDensityKgM3,
                dragCoefficient: item.dragCoefficient,
                projectedAreaM2: item.totalProjectedAreaM2(),
                currentSpeedMS: environment.currentSpeedMS
            )
        }

        let payloadCurrentForce = hydrodynamicForceN(
            waterDensityKgM3: environment.waterDensityKgM3,
            dragCoefficient: payload.dragCoefficient,
            projectedAreaM2: payloadProjectedArea,
            currentSpeedMS: environment.currentSpeedMS
        )

        let totalCurrentForce =
            buoyCurrentForce +
            mooringLineCurrentForce +
            connectorCurrentForce +
            payloadCurrentForce

        let totalCurrentForceKn = totalCurrentForce / 1000

        let waveOrbitalVelocity = approximateWaveOrbitalVelocityMS(
            waveHeightM: environment.waveHeightM,
            wavePeriodS: environment.wavePeriodS
        )

        let buoyWaveForce = hydrodynamicForceN(
            waterDensityKgM3: environment.waterDensityKgM3,
            dragCoefficient: buoy.dragCoefficient,
            projectedAreaM2: buoyProjectedArea,
            currentSpeedMS: waveOrbitalVelocity
        )

        let totalHorizontalForce = totalCurrentForce + buoyWaveForce
        let totalHorizontalForceKn = totalHorizontalForce / 1000

        let mooringLineWeightInWater = mooringLine.weightInWaterKg()

        let connectorWeightInWater = connectors.totalWeightInWaterKg(
            waterDensityKgM3: environment.waterDensityKgM3
        )

        let payloadWeightInWater = payload.weightInWaterKg(
            waterDensityKgM3: environment.waterDensityKgM3
        )

        let totalVerticalLoad =
            buoy.weightKg +
            payloadWeightInWater +
            mooringLineWeightInWater +
            connectorWeightInWater

        let buoyancyReserve =
            grossBuoyancy - totalVerticalLoad

        let mooringLineLength = mooringLine.totalLengthM()
        let mooringLineMinimumBreakingLoad = mooringLine.minimumBreakingLoadKn()
        let connectorMinimumBreakingLoad = connectors.minimumBreakingLoadKn()

        let validSystemLoads = [
            mooringLineMinimumBreakingLoad,
            connectorMinimumBreakingLoad
        ].filter { $0 > 0 }

        let systemMinimumBreakingLoad = validSystemLoads.min() ?? 0

        let systemWorkingLoad =
            safetyFactor > 0 ? systemMinimumBreakingLoad / safetyFactor : 0

        let verticalLoadN = max(totalVerticalLoad, 0) * CalculationConstants.gravityMS2
        let estimatedLineTensionN = sqrt(
            totalHorizontalForce * totalHorizontalForce +
            verticalLoadN * verticalLoadN
        )
        let estimatedLineTensionKn = estimatedLineTensionN / 1000

        let tensionSafetyRatio =
            estimatedLineTensionKn > 0 ? systemWorkingLoad / estimatedLineTensionKn : 999

        let anchorWeightInWater =
            anchor.weightInWaterKg(waterDensityKgM3: environment.waterDensityKgM3)

        let anchorEffectiveHoldingCoefficient =
            anchor.effectiveHoldingCoefficient(seabed: environment.seabed)

        let anchorHoldingCapacity =
            anchor.holdingCapacityKn(
                waterDensityKgM3: environment.waterDensityKgM3,
                seabed: environment.seabed
            )

        let requiredHolding =
            totalHorizontalForceKn

        let anchorSafetyRatio =
            requiredHolding > 0 ? anchorHoldingCapacity / requiredHolding : 999

        var maxGeometricOffset = 0.0
        var estimatedCurrentOffset = 0.0
        var mooringAngleDeg = 0.0
        var forceAngleDeg = 0.0

        var status: SystemStatus = .ok
        var messages: [String] = []

        // Проверка формы и объёма буя
        if buoyVolume <= 0 {
            status = .failed
            messages.append("Объём буя равен нулю или меньше нуля. Проверьте форму и размеры буя.")
        }

        // Проверка швартовной линии
        if mooringLine.segments.isEmpty {
            status = .failed
            messages.append("Швартовная линия не содержит участков.")
        }

        if mooringLineLength < environment.depthM {
            status = .failed
            messages.append("Суммарная длина швартовной линии меньше глубины. Система не достаёт до поверхности.")
        } else {
            maxGeometricOffset = sqrt(
                mooringLineLength * mooringLineLength -
                environment.depthM * environment.depthM
            )

            let geometricAngleRad = atan(maxGeometricOffset / environment.depthM)
            mooringAngleDeg = geometricAngleRad * 180 / Double.pi
        }

        if mooringLineMinimumBreakingLoad <= 0 {
            status = .failed
            messages.append("Не задана разрывная нагрузка для швартовной линии.")
        }

        // Проверка соединителей
        if connectors.elements.isEmpty {
            messages.append("Соединительные элементы не заданы. Для реальной системы их нужно добавить.")
        } else if connectorMinimumBreakingLoad <= 0 {
            status = .failed
            messages.append("Не задана разрывная нагрузка для соединительных элементов.")
        }

        if systemMinimumBreakingLoad <= 0 {
            status = .failed
            messages.append("Невозможно определить минимальную прочность системы.")
        }

        // Проверка плавучести
        if buoyancyReserve <= 0 {
            status = .failed
            messages.append("Недостаточная плавучесть. Буй не удержит систему.")
        } else {
            let restoringForceN = buoyancyReserve * CalculationConstants.gravityMS2

            if restoringForceN > 0 {
                let forceAngleRad = atan(totalHorizontalForce / restoringForceN)
                forceAngleDeg = forceAngleRad * 180 / Double.pi

                let calculatedOffset = environment.depthM * tan(forceAngleRad)
                estimatedCurrentOffset = min(calculatedOffset, maxGeometricOffset)
            }

            if buoyancyReserve < totalVerticalLoad * 0.2 {
                if status != .failed {
                    status = .warning
                }
                messages.append("Запас плавучести меньше 20%. Желательно увеличить объём буя.")
            } else {
                messages.append("Запас плавучести достаточный для предварительной оценки.")
            }
        }

        // Проверка коэффициента запаса системы
        if safetyFactor < 3 {
            if status != .failed {
                status = .warning
            }
            messages.append("Коэффициент запаса системы меньше 3.")
        }

        // Проверка натяжения системы
        if estimatedLineTensionKn > 0 && systemWorkingLoad > 0 {
            if estimatedLineTensionKn > systemWorkingLoad {
                status = .failed
                messages.append("Расчётное натяжение больше рабочей нагрузки системы. Самое слабое звено перегружено.")
            } else if tensionSafetyRatio < 1.5 {
                if status != .failed {
                    status = .warning
                }
                messages.append("Запас по расчётному натяжению меньше 1.5. Желательно увеличить прочность элементов или коэффициент запаса.")
            } else {
                messages.append("Запас по расчётному натяжению достаточен для предварительной оценки.")
            }
        }

        // Проверка сноса по течению
        if maxGeometricOffset > 0 && estimatedCurrentOffset > maxGeometricOffset * 0.8 {
            if status != .failed {
                status = .warning
            }
            messages.append("Расчётный снос близок к геометрическому пределу. Желательно увеличить длину линии или уменьшить сопротивление системы.")
        }

        // Проверка якоря
        if anchor.weightAirKg <= 0 {
            status = .failed
            messages.append("Масса якоря не задана. Невозможно проверить удержание.")
        } else if requiredHolding > 0 {
            if anchorSafetyRatio < 1 {
                status = .failed
                messages.append("Удерживающая способность якоря меньше расчётной горизонтальной силы.")
            } else if anchorSafetyRatio < 2 {
                if status != .failed {
                    status = .warning
                }
                messages.append("Запас удержания якоря меньше 2. Желательно увеличить массу якоря или выбрать другой тип.")
            } else {
                messages.append("Удерживающая способность якоря достаточна для предварительной оценки.")
            }
        } else {
            messages.append("Скорость течения равна нулю, проверка якоря по горизонтальной силе не критична.")
        }

        if payloadWeightInWater < 0 {
            messages.append("Прибор имеет положительную плавучесть в воде. Это уменьшает вертикальную нагрузку на буй.")
        }

        if totalCurrentForce > 0 {
            messages.append("Сила течения посчитана по упрощённой формуле сопротивления потоку.")
        }

        if buoyWaveForce > 0 {
            messages.append("Волновая нагрузка посчитана упрощённо по орбитальной скорости волны у поверхности.")
        }

        messages.append("Прочность системы оценена по самому слабому участку линии или соединителю.")

        let weakestElement = weakestElementName(
            mooringLineMinimumBreakingLoadKn: mooringLineMinimumBreakingLoad,
            connectorMinimumBreakingLoadKn: connectorMinimumBreakingLoad
        )

        let verdict = makeVerdict(
            status: status,
            buoyancyReserveKg: buoyancyReserve,
            totalVerticalLoadKg: totalVerticalLoad,
            mooringLineLengthM: mooringLineLength,
            depthM: environment.depthM,
            systemWorkingLoadKn: systemWorkingLoad,
            estimatedLineTensionKn: estimatedLineTensionKn,
            tensionSafetyRatio: tensionSafetyRatio,
            anchorSafetyRatio: anchorSafetyRatio,
            maxGeometricOffsetM: maxGeometricOffset,
            estimatedCurrentOffsetM: estimatedCurrentOffset,
            weakestElement: weakestElement
        )

        return CalculationResult(
            buoyVolumeM3: buoyVolume,
            grossBuoyancyKg: grossBuoyancy,
            buoyProjectedAreaM2: buoyProjectedArea,
            mooringLineProjectedAreaM2: mooringLineProjectedArea,
            connectorProjectedAreaM2: connectorProjectedArea,
            payloadProjectedAreaM2: payloadProjectedArea,
            buoyCurrentForceN: buoyCurrentForce,
            mooringLineCurrentForceN: mooringLineCurrentForce,
            connectorCurrentForceN: connectorCurrentForce,
            payloadCurrentForceN: payloadCurrentForce,
            totalCurrentForceN: totalCurrentForce,
            totalCurrentForceKn: totalCurrentForceKn,
            waveOrbitalVelocityMS: waveOrbitalVelocity,
            buoyWaveForceN: buoyWaveForce,
            totalHorizontalForceN: totalHorizontalForce,
            totalHorizontalForceKn: totalHorizontalForceKn,
            payloadWeightInWaterKg: payloadWeightInWater,
            mooringLineWeightInWaterKg: mooringLineWeightInWater,
            connectorWeightInWaterKg: connectorWeightInWater,
            totalVerticalLoadKg: totalVerticalLoad,
            buoyancyReserveKg: buoyancyReserve,
            mooringLineLengthM: mooringLineLength,
            mooringLineMinimumBreakingLoadKn: mooringLineMinimumBreakingLoad,
            connectorMinimumBreakingLoadKn: connectorMinimumBreakingLoad,
            systemMinimumBreakingLoadKn: systemMinimumBreakingLoad,
            systemWorkingLoadKn: systemWorkingLoad,
            estimatedLineTensionKn: estimatedLineTensionKn,
            tensionSafetyRatio: tensionSafetyRatio,
            anchorWeightInWaterKg: anchorWeightInWater,
            anchorEffectiveHoldingCoefficient: anchorEffectiveHoldingCoefficient,
            anchorHoldingCapacityKn: anchorHoldingCapacity,
            requiredHoldingKn: requiredHolding,
            anchorSafetyRatio: anchorSafetyRatio,
            maxGeometricOffsetM: maxGeometricOffset,
            estimatedCurrentOffsetM: estimatedCurrentOffset,
            mooringAngleDeg: mooringAngleDeg,
            forceAngleDeg: forceAngleDeg,
            status: status,
            messages: messages,
            verdict: verdict
        )
    }

    private func weakestElementName(
        mooringLineMinimumBreakingLoadKn: Double,
        connectorMinimumBreakingLoadKn: Double
    ) -> String {
        var candidates: [(name: String, load: Double)] = []

        if mooringLineMinimumBreakingLoadKn > 0 {
            candidates.append(("Швартовная линия", mooringLineMinimumBreakingLoadKn))
        }

        if connectorMinimumBreakingLoadKn > 0 {
            candidates.append(("Соединительные элементы", connectorMinimumBreakingLoadKn))
        }

        return candidates.min { $0.load < $1.load }?.name ?? "Не определено"
    }

    private func makeVerdict(
        status: SystemStatus,
        buoyancyReserveKg: Double,
        totalVerticalLoadKg: Double,
        mooringLineLengthM: Double,
        depthM: Double,
        systemWorkingLoadKn: Double,
        estimatedLineTensionKn: Double,
        tensionSafetyRatio: Double,
        anchorSafetyRatio: Double,
        maxGeometricOffsetM: Double,
        estimatedCurrentOffsetM: Double,
        weakestElement: String
    ) -> SystemVerdict {

        let title: String

        switch status {
        case .ok:
            title = "✅ Система предварительно подходит"
        case .warning:
            title = "⚠️ Система требует дополнительной проверки"
        case .failed:
            title = "❌ Система не подходит"
        }

        var mainRisk = "Критических рисков не выявлено."
        var recommendation = "Можно переходить к уточнению исходных данных и проверке по паспортам элементов."

        if mooringLineLengthM < depthM {
            mainRisk = "Суммарная длина швартовной линии меньше глубины."
            recommendation = "Увеличьте длину линии или пересмотрите схему постановки."
        } else if buoyancyReserveKg <= 0 {
            mainRisk = "Недостаточная плавучесть буя."
            recommendation = "Увеличьте объём буя или уменьшите массу подвешенной системы."
        } else if systemWorkingLoadKn > 0 && estimatedLineTensionKn > systemWorkingLoadKn {
            mainRisk = "Расчётное натяжение превышает рабочую нагрузку системы."
            recommendation = "Увеличьте прочность самого слабого элемента: \(weakestElement)."
        } else if anchorSafetyRatio < 1 {
            mainRisk = "Якорь не удерживает расчётную горизонтальную нагрузку."
            recommendation = "Увеличьте массу якоря, измените тип якоря или уточните грунт."
        } else if buoyancyReserveKg < totalVerticalLoadKg * 0.2 {
            mainRisk = "Малый запас плавучести."
            recommendation = "Желательно иметь больший запас плавучести для реальных условий."
        } else if tensionSafetyRatio < 1.5 {
            mainRisk = "Малый запас по натяжению системы."
            recommendation = "Проверьте слабое звено и увеличьте рабочую нагрузку системы."
        } else if anchorSafetyRatio < 2 {
            mainRisk = "Малый запас удержания якоря."
            recommendation = "Желательно увеличить запас удержания якоря."
        } else if maxGeometricOffsetM > 0 && estimatedCurrentOffsetM > maxGeometricOffsetM * 0.8 {
            mainRisk = "Снос близок к геометрическому пределу."
            recommendation = "Увеличьте длину линии или уменьшите сопротивление элементов."
        }

        return SystemVerdict(
            title: title,
            mainRisk: mainRisk,
            weakestElement: weakestElement,
            recommendation: recommendation
        )
    }

    private func approximateWaveOrbitalVelocityMS(
        waveHeightM: Double,
        wavePeriodS: Double
    ) -> Double {
        if waveHeightM <= 0 || wavePeriodS <= 0 {
            return 0
        }

        // Упрощённая оценка горизонтальной орбитальной скорости волны у поверхности:
        // u ≈ πH / T
        return Double.pi * waveHeightM / wavePeriodS
    }

    private func hydrodynamicForceN(
        waterDensityKgM3: Double,
        dragCoefficient: Double,
        projectedAreaM2: Double,
        currentSpeedMS: Double
    ) -> Double {
        if currentSpeedMS <= 0 || projectedAreaM2 <= 0 {
            return 0
        }

        return 0.5 *
            waterDensityKgM3 *
            dragCoefficient *
            projectedAreaM2 *
            currentSpeedMS *
            currentSpeedMS
    }
}
